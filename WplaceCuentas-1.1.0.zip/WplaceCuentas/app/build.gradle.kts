plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val geckoArtifact = providers.gradleProperty("geckoArtifact").getOrElse("geckoview-omni-arm64-v8a")
val geckoVersion = providers.gradleProperty("geckoVersion").getOrElse("140.0.20250707120347")

base {
    archivesName.set("WplaceCuentas")
}

// --- Firma estable ---
// Para que cada versión nueva se pueda instalar ENCIMA de la anterior (sin desinstalar),
// todos los APK deben firmarse con la MISMA clave. Pásala por variables de entorno o gradle.properties
// (ver README, apartado «Actualizaciones»). Sin ellas se usa la clave debug de la máquina que compila.
fun secret(name: String): String? =
    (System.getenv(name) ?: providers.gradleProperty(name).orNull)?.takeIf { it.isNotBlank() }
val ksFile = secret("WPLACE_KEYSTORE_FILE")
val ksPass = secret("WPLACE_KEYSTORE_PASSWORD")
val ksAlias = secret("WPLACE_KEY_ALIAS")
val ksKeyPass = secret("WPLACE_KEY_PASSWORD")
val hasKeystore = ksFile != null && ksPass != null && ksAlias != null && file(ksFile!!).exists()

android {
    namespace = "app.wplacecuentas"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.wplacecuentas"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.0"
    }

    signingConfigs {
        if (hasKeystore) {
            create("release") {
                storeFile = file(ksFile!!)
                storePassword = ksPass!!
                keyAlias = ksAlias!!
                keyPassword = ksKeyPass ?: ksPass
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
        debug {
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { viewBinding = true }

    // La compilación en GitHub Actions no debe fallar por avisos de lint.
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging { jniLibs { useLegacyPackaging = true } }
    androidResources { noCompress += "ja" }
}

dependencies {
    implementation("org.mozilla.geckoview:$geckoArtifact:$geckoVersion")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
}
