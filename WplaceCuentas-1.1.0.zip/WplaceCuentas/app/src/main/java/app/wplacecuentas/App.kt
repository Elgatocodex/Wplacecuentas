package app.wplacecuentas

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import java.io.File

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // GeckoView lanza procesos hijos (:tab, :gpu...) que también ejecutan esto.
        // Solo el proceso principal necesita cargar datos y crear el canal.
        if (!isMainProcess()) return

        AccountStore.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "Píxeles listos", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Avisa cuando una cuenta ya tiene píxeles otra vez"
        nm.createNotificationChannel(ch)
    }

    private fun isMainProcess(): Boolean {
        val name: String? = if (Build.VERSION.SDK_INT >= 28) {
            Application.getProcessName()
        } else {
            try {
                File("/proc/self/cmdline").readText().trim { it <= ' ' || it == '\u0000' }
            } catch (e: Exception) {
                null
            }
        }
        return name == null || name == packageName
    }

    companion object {
        const val CHANNEL_ID = "pixeles"
    }
}
