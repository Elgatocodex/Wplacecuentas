package app.wplacecuentas

import android.app.NotificationManager
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import app.wplacecuentas.databinding.ActivityBrowserBinding
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.mozilla.geckoview.GeckoSession

class BrowserActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_ID = "id"
        const val EXTRA_TEST = "test"
        const val TEST_ID = "prueba"
        private const val STATE_ID = "cur"
    }

    private lateinit var b: ActivityBrowserBinding
    private var currentId = ""
    private var testMode = false
    private var blockedShown = false
    private var expanded = true
    private var loginContext = false
    private val chips = LinkedHashMap<String, MaterialButton>()
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refreshBar()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Sin aceptar los términos no se abre el navegador (p. ej. al tocar una notificación antigua).
        if (!Legal.accepted(this)) {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
            finish()
            return
        }

        b = ActivityBrowserBinding.inflate(layoutInflater)
        setContentView(b.root)
        Browser.runtime(this) // arranca Gecko

        b.btnList.setOnClickListener { goToList() }
        b.btnEmpty.setOnClickListener { markEmpty() }
        b.btnNext.setOnClickListener { goNext() }
        b.btnClosePopup.setOnClickListener { Browser.closePopup(currentId) }
        b.btnEndTest.setOnClickListener { finish() }
        b.handle.setOnClickListener { setExpanded(!expanded) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    b.popupLayer.visibility == View.VISIBLE -> Browser.closePopup(currentId)
                    Browser.canGoBack(currentId) -> Browser.goBack(currentId)
                    else -> goToList()
                }
            }
        })

        // Si Android cerró la app en segundo plano, volvemos a la cuenta en la que estabas.
        handleIntent(intent, savedInstanceState?.getString(STATE_ID))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, null)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (currentId.isNotEmpty() && currentId != TEST_ID) outState.putString(STATE_ID, currentId)
    }

    override fun onStart() {
        super.onStart()
        // Gecko se había dormido en onStop(): lo despertamos antes de que el usuario vea la pantalla.
        runCatching { b.gecko.session?.setActive(true) }
        if (b.popupLayer.visibility == View.VISIBLE) runCatching { b.popupGecko.session?.setActive(true) }
    }

    override fun onResume() {
        super.onResume()
        Browser.onGoogleBlocked = { showBlocked() }
        Browser.onPopup = { p -> showPopup(p, 0) }
        Browser.onPopupClosed = { syncPopup() }
        Browser.onSessionState = { refreshBar() }
        Browser.onSessionLost = { id -> if (id == currentId) rebind() }
        Browser.onNavigate = { id, url -> onUrl(id, url) }
        Browser.onLoading = { id, loading ->
            if (id == currentId) b.loading.visibility = if (loading) View.VISIBLE else View.GONE
        }
        getSystemService(NotificationManager::class.java).cancel(currentId.hashCode())

        // Lo que pudo pasar mientras estabas en Gmail u otra app:
        rebind()      // la página se cerró/colgó -> se reabre donde estaba
        syncPopup()   // un popup de login se abrió o se cerró -> se refleja ahora
        refreshBar()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        Browser.onGoogleBlocked = null
        Browser.onPopup = null
        Browser.onPopupClosed = null
        Browser.onSessionState = null
        Browser.onSessionLost = null
        Browser.onNavigate = null
        Browser.onLoading = null
        // Guarda la página de cada cuenta por si Android cierra la app en segundo plano.
        Browser.persistStates(this)
    }

    override fun onStop() {
        super.onStop()
        // En segundo plano Gecko se duerme (menos batería y menos riesgo de que Android lo mate).
        runCatching { b.gecko.session?.setActive(false) }
        runCatching { b.popupGecko.session?.setActive(false) }
    }

    override fun onDestroy() {
        if (::b.isInitialized) {
            runCatching { b.popupGecko.releaseSession() }
            runCatching { b.gecko.releaseSession() }
            if (isFinishing && testMode) Browser.delete(this, TEST_ID)
        }
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)

    // ---------- Navegación entre cuentas ----------
    private fun handleIntent(i: Intent?, restoredId: String?) {
        testMode = i?.getBooleanExtra(EXTRA_TEST, false) == true
        if (testMode) {
            b.accountBar.visibility = View.GONE
            b.testBar.visibility = View.VISIBLE
            currentId = TEST_ID
            open(TEST_ID, Browser.URL_GOOGLE)
            return
        }
        b.accountBar.visibility = View.VISIBLE
        b.testBar.visibility = View.GONE
        val id = listOf(
            restoredId,
            i?.getStringExtra(EXTRA_ID),
            currentId.takeIf { it.isNotEmpty() && it != TEST_ID },
            AccountStore.lastId(),
            AccountStore.all().firstOrNull()?.id
        ).firstOrNull { it != null && AccountStore.get(it) != null }

        if (id == null) {
            goToList()
            return
        }
        show(id)
    }

    private fun show(id: String) {
        if (AccountStore.get(id) == null) {
            goToList()
            return
        }
        currentId = id
        AccountStore.setLastId(id)
        open(id, Browser.URL_WPLACE)
        loginContext = Browser.urlOf(id).contains("accounts.google.com")
        setExpanded(!loginContext)
        refreshBar()
    }

    /** Se asegura de que la vista muestre la sesión viva de la cuenta actual. */
    private fun rebind() {
        if (currentId.isEmpty()) return
        if (!testMode && AccountStore.get(currentId) == null) {
            goToList()
            return
        }
        val live = Browser.liveSession(currentId)
        if (live == null || b.gecko.session !== live) {
            open(currentId, if (testMode) Browser.URL_GOOGLE else Browser.URL_WPLACE)
        } else {
            runCatching { live.setActive(true) }
        }
    }

    // ---------- Barra discreta: se esconde sola durante el login de Google ----------
    private fun setExpanded(v: Boolean) {
        expanded = v
        b.barContent.visibility = if (v) View.VISIBLE else View.GONE
    }

    private fun onUrl(id: String, url: String) {
        if (testMode || id != currentId) return
        val g = url.contains("accounts.google.com")
        if (g != loginContext) {
            loginContext = g
            setExpanded(!g)
        }
    }

    private fun switchTo(id: String) {
        if (id == currentId) return
        Browser.closePopup(currentId)
        show(id)
    }

    /** Suelta la sesión actual de la vista (sigue viva en memoria) y muestra la de `id`. */
    private fun open(id: String, url: String) {
        hidePopup()
        b.loading.visibility = View.GONE
        val prev: GeckoSession? = runCatching { b.gecko.releaseSession() }.getOrNull()
        val s = Browser.sessionFor(this, id, url)
        if (prev != null && prev !== s) runCatching { prev.setActive(false) }
        b.gecko.setSession(s)
        s.setActive(true)
    }

    private fun goToList() {
        if (!testMode) {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
        finish()
    }

    private fun goNext() {
        val c = AccountStore.config()
        val now = System.currentTimeMillis()
        val next = Timers.sorted(AccountStore.all(), c, now)
            .firstOrNull { it.id != currentId && Timers.bucket(it, c, now) <= 1 }
        if (next == null) {
            Toast.makeText(this, "Ninguna otra cuenta tiene píxeles ahora mismo", Toast.LENGTH_SHORT).show()
        } else {
            switchTo(next.id)
        }
    }

    private fun markEmpty() {
        val a = AccountStore.update(currentId) { it.copy(emptyAt = System.currentTimeMillis()) } ?: return
        Alarms.schedule(this, a)
        val rem = Timers.remaining(a, AccountStore.config(), System.currentTimeMillis())
        Toast.makeText(this, "${a.name}: te aviso en ${Timers.fmt(rem)}", Toast.LENGTH_LONG).show()
        refreshBar()
    }

    // ---------- Ventana emergente (login en popup) ----------
    /** Muestra u oculta el popup según lo que realmente exista ahora mismo. */
    private fun syncPopup() {
        val p = Browser.popupFor(currentId)
        val showing = b.popupLayer.visibility == View.VISIBLE
        if (p != null && !showing) {
            showPopup(p, 0)
        } else if (p == null && showing) {
            hidePopup()
        }
    }

    private fun showPopup(p: GeckoSession, tries: Int) {
        try {
            b.popupLayer.visibility = View.VISIBLE
            setExpanded(false)
            b.popupGecko.releaseSession()
            b.popupGecko.setSession(p)
            p.setActive(true)
        } catch (e: Exception) {
            // la sesión aún no está abierta: reintentar un momento después
            if (tries < 20) handler.postDelayed({ showPopup(p, tries + 1) }, 50)
        }
    }

    private fun hidePopup() {
        runCatching { b.popupGecko.releaseSession() }
        val wasPopup = b.popupLayer.visibility == View.VISIBLE
        b.popupLayer.visibility = View.GONE
        if (wasPopup) setExpanded(!loginContext)
    }

    private fun showBlocked() {
        if (blockedShown) return
        blockedShown = true
        MaterialAlertDialogBuilder(this)
            .setTitle("Google bloqueó el inicio de sesión")
            .setMessage(
                "Google rechazó el navegador integrado (error 403 / disallowed_useragent). " +
                    "Suele arreglarse con una versión más reciente de la app, que puedes descargar en " +
                    "${Links.UPDATES_LABEL}."
            )
            .setPositiveButton("Buscar actualización") { _, _ -> Links.open(this, Links.UPDATES) }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    // ---------- Barra inferior ----------
    private fun refreshBar() {
        if (testMode) return
        val accs = AccountStore.all()
        val c = AccountStore.config()
        val now = System.currentTimeMillis()
        syncChips(accs, c, now)

        val acc = accs.firstOrNull { it.id == currentId } ?: return
        val parts = mutableListOf(Timers.timerLine(acc, c, now))
        val ses = Timers.sessionLine(acc)
        if (ses != null && acc.sessionState != SessionState.OK) parts.add(ses)
        b.statusText.text = acc.name + " · " + parts.joinToString(" · ")
        b.statusText.setTextColor(
            color(if (acc.sessionState == SessionState.EXPIRED) R.color.warn else R.color.muted)
        )
    }

    private fun syncChips(accs: List<Account>, c: Config, now: Long) {
        if (accs.map { it.id } != chips.keys.toList()) {
            b.chipRow.removeAllViews()
            chips.clear()
            for (a in accs) {
                val btn = MaterialButton(this).apply {
                    insetTop = 0
                    insetBottom = 0
                    minimumWidth = 0
                    textSize = 13f
                    cornerRadius = dp(19)
                    strokeWidth = dp(1)
                    setPadding(dp(16), 0, dp(16), 0)
                    setOnClickListener { switchTo(a.id) }
                }
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38))
                lp.marginEnd = dp(8)
                b.chipRow.addView(btn, lp)
                chips[a.id] = btn
            }
        }
        for (a in accs) {
            val btn = chips[a.id] ?: continue
            val ready = Timers.hasTimer(a) && Timers.remaining(a, c, now) == 0L
            val sel = a.id == currentId
            btn.text = (if (ready) "● " else "") + a.name
            btn.backgroundTintList = ColorStateList.valueOf(color(if (sel) R.color.accent else R.color.chip))
            btn.strokeColor = ColorStateList.valueOf(color(if (sel) R.color.accent else R.color.outline))
            btn.setTextColor(
                color(
                    when {
                        sel -> R.color.on_accent
                        ready -> R.color.accent
                        else -> R.color.text
                    }
                )
            )
        }
    }
}
