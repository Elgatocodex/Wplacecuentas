package app.wplacecuentas

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import app.wplacecuentas.databinding.ActivityMainBinding
import app.wplacecuentas.databinding.DialogConsentBinding
import app.wplacecuentas.databinding.DialogSettingsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: AccountAdapter
    private var consentDialog: AlertDialog? = null
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }
    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        adapter = AccountAdapter(::openAccount, ::markEmpty, ::showMenu)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.list.itemAnimator = null

        b.versionText.text = "v" + Links.versionName(this)
        b.fabAdd.setOnClickListener { requireConsent { addAccount() } }
        b.btnUpdate.setOnClickListener { showUpdates() }
        b.btnMenu.setOnClickListener { showMainMenu(it) }
        b.btnFacebook.setOnClickListener { Links.open(this, Links.FACEBOOK) }
        b.btnGithub.setOnClickListener { Links.open(this, Links.GITHUB) }
        b.btnTerms.setOnClickListener { openLegal(LegalActivity.DOC_TERMS) }
        b.btnPrivacy.setOnClickListener { openLegal(LegalActivity.DOC_PRIVACY) }
        b.btnLicenses.setOnClickListener { openLegal(LegalActivity.DOC_LICENSES) }

        if (Legal.accepted(this)) askNotificationPermission() else ensureConsent()
    }

    override fun onResume() {
        super.onResume()
        Alarms.rescheduleAll(this)
        Browser.onSessionState = { refresh() }
        handler.post(ticker)
        if (!Legal.accepted(this)) ensureConsent() // p. ej. si se subió la versión de los términos
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        Browser.onSessionState = null
    }

    override fun onDestroy() {
        consentDialog?.dismiss()
        consentDialog = null
        super.onDestroy()
    }

    // ---------- Aceptación de términos y privacidad ----------
    private fun ensureConsent() {
        if (Legal.accepted(this) || consentDialog?.isShowing == true) return

        val d = DialogConsentBinding.inflate(layoutInflater)
        d.btnReadTerms.setOnClickListener { openLegal(LegalActivity.DOC_TERMS) }
        d.btnReadPrivacy.setOnClickListener { openLegal(LegalActivity.DOC_PRIVACY) }

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.consent_title)
            .setView(d.root)
            .setCancelable(false)
            .setPositiveButton(R.string.consent_accept, null)
            .setNegativeButton(R.string.consent_exit) { _, _ -> finishAffinity() }
            .create()
        dialog.setOnShowListener {
            val ok = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            ok.isEnabled = d.check.isChecked
            d.check.setOnCheckedChangeListener { _, checked -> ok.isEnabled = checked }
            ok.setOnClickListener {
                if (d.check.isChecked) {
                    Legal.accept(this)
                    dialog.dismiss()
                    askNotificationPermission()
                }
            }
        }
        consentDialog = dialog
        dialog.show()
    }

    private fun requireConsent(then: () -> Unit) {
        if (Legal.accepted(this)) then() else ensureConsent()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ---------- Menú ----------
    private fun showMainMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menuInflater.inflate(R.menu.main_menu, pm.menu)
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_settings -> showSettings()
                R.id.action_updates -> showUpdates()
                R.id.action_test -> requireConsent { startTest() }
                R.id.action_terms -> openLegal(LegalActivity.DOC_TERMS)
                R.id.action_privacy -> openLegal(LegalActivity.DOC_PRIVACY)
                R.id.action_licenses -> openLegal(LegalActivity.DOC_LICENSES)
                R.id.action_wipe -> confirmWipe()
                R.id.action_about -> showAbout()
            }
            true
        }
        pm.show()
    }

    private fun openLegal(doc: Int) {
        startActivity(LegalActivity.intent(this, doc))
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.app_name))
            .setMessage(getString(R.string.about_message, Links.versionName(this), Links.UPDATES_LABEL))
            .setPositiveButton("Facebook") { _, _ -> Links.open(this, Links.FACEBOOK) }
            .setNeutralButton("GitHub") { _, _ -> Links.open(this, Links.GITHUB) }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    private fun showUpdates() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.updates_button)
            .setMessage(getString(R.string.updates_message, Links.versionName(this), Links.UPDATES_LABEL))
            .setPositiveButton("Abrir sitio") { _, _ -> Links.open(this, Links.UPDATES) }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    private fun confirmWipe() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Borrar todos mis datos")
            .setMessage(
                "Se eliminarán todas las cuentas, sus sesiones (cookies y datos de wplace y de Google), " +
                    "los temporizadores, los avisos programados y los ajustes de este dispositivo.\n\n" +
                    "No se puede deshacer. Tus cuentas de Google y de wplace no se borran: " +
                    "solo se cierra su sesión aquí."
            )
            .setPositiveButton("Borrar todo") { _, _ ->
                AccountStore.all().forEach { Alarms.cancel(this, it.id) }
                Browser.deleteAll(this)
                AccountStore.clearAll()
                refresh()
                Toast.makeText(this, "Datos borrados", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Lista ----------
    private fun refresh() {
        val c = AccountStore.config()
        val now = System.currentTimeMillis()
        val accs = AccountStore.all()
        val rows = Timers.sorted(accs, c, now).map { a ->
            Row(
                id = a.id,
                name = a.name,
                timer = Timers.cardLine(a, c, now),
                session = Timers.sessionLine(a),
                warn = a.sessionState == SessionState.EXPIRED,
                bucket = Timers.bucket(a, c, now),
                hasTimer = Timers.hasTimer(a),
                px = Timers.pixels(a, c, now) ?: 0,
                maxPx = c.maxPixels
            )
        }
        adapter.submitList(rows)
        b.emptyState.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE

        if (rows.isEmpty()) {
            b.summary.visibility = View.GONE
        } else {
            val ready = rows.count { it.bucket == 0 }
            val waiting = rows.count { it.bucket == 2 }
            b.summary.visibility = View.VISIBLE
            b.summary.text = "● $ready listas   ⏳ $waiting en espera   ·   ${rows.size} " +
                if (rows.size == 1) "cuenta" else "cuentas"
        }
    }

    // ---------- Acciones ----------
    private fun openAccount(id: String) {
        requireConsent {
            startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_ID, id))
        }
    }

    private fun addAccount() {
        val names = AccountStore.all().map { it.name }.toSet()
        var n = AccountStore.all().size + 1
        while ("Cuenta $n" in names) n++
        val a = AccountStore.add("Cuenta $n")
        refresh()
        openAccount(a.id)
    }

    private fun markEmpty(id: String) {
        val a = AccountStore.update(id) { it.copy(emptyAt = System.currentTimeMillis()) } ?: return
        Alarms.schedule(this, a)
        val c = AccountStore.config()
        val rem = Timers.remaining(a, c, System.currentTimeMillis())
        Toast.makeText(this, "${a.name}: te aviso en ${Timers.fmt(rem)}", Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun showMenu(id: String, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menuInflater.inflate(R.menu.account_menu, pm.menu)
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.rename -> rename(id)
                R.id.clear_timer -> clearTimer(id)
                R.id.delete -> confirmDelete(id)
            }
            true
        }
        pm.show()
    }

    private fun rename(id: String) {
        val a = AccountStore.get(id) ?: return
        val input = EditText(this).apply {
            setText(a.name)
            setSelection(text.length)
            setSingleLine()
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Nombre de la cuenta")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) {
                    AccountStore.update(id) { it.copy(name = n) }
                    refresh()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun clearTimer(id: String) {
        val a = AccountStore.update(id) { it.copy(emptyAt = 0L) } ?: return
        Alarms.cancel(this, a.id)
        refresh()
    }

    private fun confirmDelete(id: String) {
        val a = AccountStore.get(id) ?: return
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar «${a.name}»")
            .setMessage("Se borrará la sesión de esta cuenta (cookies y datos de wplace y de Google) en este dispositivo. No se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                Alarms.cancel(this, id)
                Browser.delete(this, id)
                AccountStore.remove(id)
                refresh()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startTest() {
        startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_TEST, true))
    }

    private fun showSettings() {
        val c = AccountStore.config()
        val d = DialogSettingsBinding.inflate(layoutInflater)
        d.inMpp.setText(c.minutesPerPixel.toString())
        d.inMax.setText(c.maxPixels.toString())
        d.inNotify.setText(c.notifyAt.toString())
        d.inPages.setText(c.pagesInMemory.toString())
        MaterialAlertDialogBuilder(this)
            .setTitle("Temporizador y ajustes")
            .setView(d.root)
            .setPositiveButton("Guardar") { _, _ ->
                val mpp = d.inMpp.text.toString().replace(',', '.').toDoubleOrNull()
                val max = d.inMax.text.toString().toIntOrNull()
                val notify = d.inNotify.text.toString().toIntOrNull()
                val pages = d.inPages.text.toString().toIntOrNull()
                if (mpp == null || mpp <= 0.0 || max == null || max < 1 ||
                    notify == null || notify < 1 || pages == null || pages < 1
                ) {
                    Toast.makeText(this, "Valores no válidos, no se guardó nada", Toast.LENGTH_LONG).show()
                } else {
                    AccountStore.saveConfig(Config(mpp, max, notify.coerceAtMost(max), pages))
                    Alarms.rescheduleAll(this)
                    refresh()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
