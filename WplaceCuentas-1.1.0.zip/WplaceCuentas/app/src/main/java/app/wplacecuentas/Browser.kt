package app.wplacecuentas

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebExtension
import java.io.File
import java.util.concurrent.Executors

/**
 * Un único GeckoRuntime para todo el proceso y una GeckoSession por cuenta.
 * Cada sesión usa su propio "contextId" => cookies, localStorage y caché completamente separados.
 * Las sesiones viven aquí (no en la Activity), así que cambiar de cuenta no recarga la página.
 *
 * Robustez en segundo plano (p. ej. al salir a Gmail a copiar un código y volver):
 *  - El estado de navegación de cada cuenta se guarda en disco, así que si Android mata la app
 *    se reabre exactamente en la página donde estabas (por ejemplo, en el paso de Google).
 *  - Los popups de login y las sesiones caídas se recuerdan aunque la pantalla esté pausada;
 *    la Activity los recupera al volver (ver BrowserActivity.onResume).
 */
object Browser {
    private const val TAG = "WplaceCuentas"
    const val URL_WPLACE = "https://wplace.live/"
    const val URL_GOOGLE = "https://accounts.google.com/"
    private const val EXT_URI = "resource://android/assets/messaging/"
    private const val EXT_ID = "messaging@wplacecuentas.app"
    private const val MAX_STATE_CHARS = 300_000

    private var rt: GeckoRuntime? = null
    private var appCtx: Context? = null
    private var extension: WebExtension? = null
    private val sessions = HashMap<String, GeckoSession>()
    private val popups = HashMap<String, GeckoSession>()
    private val backMap = HashMap<String, Boolean>()
    private val lru = LinkedHashSet<String>()
    private val main = Handler(Looper.getMainLooper())
    private val savedStates = HashMap<String, GeckoSession.SessionState>()
    private val stateWriter = Executors.newSingleThreadExecutor()

    var onGoogleBlocked: (() -> Unit)? = null
    var onPopup: ((GeckoSession) -> Unit)? = null
    var onPopupClosed: (() -> Unit)? = null
    var onSessionLost: ((String) -> Unit)? = null
    var onSessionState: ((String) -> Unit)? = null

    /** (id de cuenta, url) cada vez que la página principal empieza a cargar una URL. */
    var onNavigate: ((String, String) -> Unit)? = null

    /** (id de cuenta, cargando) para mostrar la barrita de carga. */
    var onLoading: ((String, Boolean) -> Unit)? = null
    private val urls = HashMap<String, String>()

    fun urlOf(id: String): String = urls[id] ?: ""

    private fun contextFor(id: String) = "acc$id"

    // ---------- Runtime ----------
    fun runtime(ctx: Context): GeckoRuntime {
        rt?.let { return it }
        appCtx = ctx.applicationContext
        val settings = GeckoRuntimeSettings.Builder()
            .javaScriptEnabled(true)
            .remoteDebuggingEnabled(false)
            .aboutConfigEnabled(false)
            .build()
        val r = GeckoRuntime.create(ctx.applicationContext, settings)
        rt = r
        installExtension(r)
        return r
    }

    private fun <T> GeckoResult<T>.onDone(ok: (T?) -> Unit, err: (Throwable) -> Unit) {
        this.accept(
            GeckoResult.Consumer<T> { value -> ok(value) },
            GeckoResult.Consumer<Throwable> { e -> err(e ?: RuntimeException("error desconocido")) }
        )
    }

    private fun installExtension(r: GeckoRuntime) {
        r.webExtensionController.ensureBuiltIn(EXT_URI, EXT_ID).onDone(
            { ext ->
                if (ext != null) {
                    extension = ext
                    for ((id, s) in sessions) attachExt(s, id)
                }
            },
            { e -> Log.e(TAG, "No se pudo instalar la extensión interna", e) }
        )
    }

    private fun attachExt(s: GeckoSession, id: String) {
        val ext = extension ?: return
        try {
            s.webExtensionController.setMessageDelegate(
                ext,
                object : WebExtension.MessageDelegate {
                    override fun onMessage(
                        nativeApp: String,
                        message: Any,
                        sender: WebExtension.MessageSender
                    ): GeckoResult<Any>? {
                        handleMessage(id, message)
                        return null
                    }
                },
                "browser"
            )
        } catch (e: Exception) {
            Log.e(TAG, "setMessageDelegate", e)
        }
    }

    private fun handleMessage(id: String, message: Any) {
        val json = message as? JSONObject ?: return
        if (json.optString("type") != "auth") return
        // La cuenta pudo borrarse mientras llegaba el mensaje.
        if (AccountStore.get(id) == null) return
        when (json.optString("state")) {
            "ok" -> AccountStore.update(id) {
                it.copy(sessionState = SessionState.OK, loggedInEver = true)
            }
            "out" -> AccountStore.update(id) {
                it.copy(sessionState = if (it.loggedInEver) SessionState.EXPIRED else SessionState.LOGGED_OUT)
            }
            else -> return
        }
        main.post { onSessionState?.invoke(id) }
    }

    // ---------- Sesiones ----------
    fun sessionFor(ctx: Context, id: String, startUrl: String): GeckoSession {
        val s = sessions[id] ?: create(ctx, id, startUrl)
        touch(id)
        return s
    }

    /** La sesión viva de esa cuenta, o null si Android/Gecko la cerró. */
    fun liveSession(id: String): GeckoSession? = sessions[id]

    /** El popup de login abierto para esa cuenta, si hay uno. */
    fun popupFor(id: String): GeckoSession? = popups[id]

    private fun create(ctx: Context, id: String, startUrl: String): GeckoSession {
        val r = runtime(ctx)
        val settings = GeckoSessionSettings.Builder()
            .contextId(contextFor(id))   // <- aislamiento total por cuenta
            .build()
        val s = GeckoSession(settings)
        wire(s, id, settings, false)
        s.open(r)
        sessions[id] = s
        attachExt(s, id)

        // Si hay un estado guardado (p. ej. estabas a mitad del login de Google), lo recuperamos.
        val saved = if (id == BrowserActivity.TEST_ID) null else loadState(ctx, id)
        var restored = false
        if (saved != null) {
            try {
                s.restoreState(saved)
                restored = true
            } catch (e: Exception) {
                Log.w(TAG, "No se pudo restaurar la página de $id", e)
            }
        }
        if (!restored) s.loadUri(startUrl)
        return s
    }

    private fun wire(s: GeckoSession, id: String, settings: GeckoSessionSettings, isPopup: Boolean) {
        var lastUrl = ""
        val backKey = if (isPopup) "$id#popup" else id

        s.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                if (lastUrl.contains("accounts.google.com") && title != null &&
                    (title.contains("403") || title.contains("disallowed", ignoreCase = true))
                ) {
                    onGoogleBlocked?.invoke()
                }
            }

            override fun onCloseRequest(session: GeckoSession) {
                if (isPopup) closePopup(id)
            }

            override fun onCrash(session: GeckoSession) {
                // Si la página se cuelga, no reabrimos el mismo estado (podría colgarse otra vez).
                if (!isPopup) lost(id, crashed = true) else closePopup(id)
            }

            override fun onKill(session: GeckoSession) {
                // Android liberó memoria: conservamos el estado para reabrir donde estabas.
                if (!isPopup) lost(id, crashed = false) else closePopup(id)
            }
        }

        s.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                lastUrl = url
                if (!isPopup) {
                    urls[id] = url
                    onNavigate?.invoke(id, url)
                    onLoading?.invoke(id, true)
                }
                if (url.contains("disallowed_useragent")) onGoogleBlocked?.invoke()
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                if (!isPopup) onLoading?.invoke(id, false)
            }

            override fun onSessionStateChange(
                session: GeckoSession,
                sessionState: GeckoSession.SessionState
            ) {
                if (!isPopup && id != BrowserActivity.TEST_ID) savedStates[id] = sessionState
            }
        }

        s.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                backMap[backKey] = canGoBack
            }

            // Ventanas emergentes (p. ej. "Iniciar sesión con Google" en popup)
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                if (isPopup) return null
                return openPopup(id, settings)
            }
        }
    }

    private fun openPopup(id: String, settings: GeckoSessionSettings): GeckoResult<GeckoSession> {
        popups.remove(id)?.let { runCatching { it.close() } }
        val p = GeckoSession(settings)
        wire(p, id, settings, true)
        popups[id] = p
        // Si la pantalla está pausada (el usuario fue a Gmail) onPopup es null; la Activity
        // recoge el popup pendiente con popupFor() cuando vuelve.
        main.post { onPopup?.invoke(p) }
        return GeckoResult.fromValue(p)
    }

    fun closePopup(id: String) {
        val p = popups.remove(id) ?: return
        backMap.remove("$id#popup")
        main.post { onPopupClosed?.invoke() }
        runCatching { p.close() }
    }

    private fun lost(id: String, crashed: Boolean) {
        if (crashed) forgetState(id)
        close(id)
        lru.remove(id)
        main.post { onSessionLost?.invoke(id) }
    }

    /** Mantiene como máximo N páginas cargadas (las más recientes). Las demás se recargan al abrirlas. */
    private fun touch(id: String) {
        lru.remove(id)
        lru.add(id)
        val max = AccountStore.config().pagesInMemory.coerceAtLeast(1)
        while (lru.size > max) {
            val victim = lru.firstOrNull { it != id } ?: break
            lru.remove(victim)
            close(victim)
        }
    }

    private fun close(id: String) {
        popups.remove(id)?.let { runCatching { it.close() } }
        sessions.remove(id)?.let { runCatching { it.close() } }
        urls.remove(id)
        backMap.remove(id)
        backMap.remove("$id#popup")
    }

    // ---------- Estado guardado en disco ----------
    private fun stateDir(ctx: Context) = File(ctx.applicationContext.filesDir, "sessions")

    private fun loadState(ctx: Context, id: String): GeckoSession.SessionState? {
        savedStates[id]?.let { return it }
        return try {
            val f = File(stateDir(ctx), "$id.state")
            if (f.isFile) GeckoSession.SessionState.fromString(f.readText()) else null
        } catch (e: Exception) {
            null
        }
    }

    private fun forgetState(id: String) {
        savedStates.remove(id)
        val c = appCtx ?: return
        runCatching { File(stateDir(c), "$id.state").delete() }
    }

    /** Guarda en disco la página de cada cuenta. Se llama al pausar la pantalla. */
    fun persistStates(ctx: Context) {
        val dir = stateDir(ctx)
        val dump = HashMap<String, String>()
        for ((id, st) in savedStates) {
            try {
                val text = st.toString()
                if (text.length <= MAX_STATE_CHARS) dump[id] = text
            } catch (e: Exception) {
                // se ignora: se guardará en la próxima pausa
            }
        }
        if (dump.isEmpty()) return
        stateWriter.execute {
            try {
                dir.mkdirs()
                for ((id, text) in dump) File(dir, "$id.state").writeText(text)
            } catch (e: Exception) {
                Log.w(TAG, "No se pudo guardar el estado de las páginas", e)
            }
        }
    }

    /** Elimina la sesión: cierra la página y borra cookies/almacenamiento de esa cuenta. */
    fun delete(ctx: Context, id: String) {
        close(id)
        lru.remove(id)
        appCtx = ctx.applicationContext
        forgetState(id)
        try {
            runtime(ctx).storageController.clearDataForSessionContext(contextFor(id))
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo borrar el almacenamiento", e)
        }
    }

    /** Borra todas las cuentas y todo lo guardado en este dispositivo. */
    fun deleteAll(ctx: Context) {
        for (a in AccountStore.all()) delete(ctx, a.id)
        runCatching { stateDir(ctx).deleteRecursively() }
        savedStates.clear()
    }

    fun canGoBack(id: String) = backMap[id] == true

    fun goBack(id: String) {
        sessions[id]?.goBack(true)
    }
}
