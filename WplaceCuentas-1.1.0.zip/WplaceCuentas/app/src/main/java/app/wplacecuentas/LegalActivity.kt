package app.wplacecuentas

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.text.method.LinkMovementMethod
import androidx.appcompat.app.AppCompatActivity
import app.wplacecuentas.databinding.ActivityLegalBinding
import com.google.android.material.tabs.TabLayout

/** Muestra los Términos de servicio, la Política de privacidad y las licencias (assets/legal/*.html). */
class LegalActivity : AppCompatActivity() {
    companion object {
        private const val EXTRA_DOC = "doc"
        const val DOC_TERMS = 0
        const val DOC_PRIVACY = 1
        const val DOC_LICENSES = 2

        private val FILES = arrayOf("legal/terms.html", "legal/privacy.html", "legal/licenses.html")
        private val TITLES = arrayOf("Términos", "Privacidad", "Licencias")

        fun intent(ctx: Context, doc: Int): Intent =
            Intent(ctx, LegalActivity::class.java).putExtra(EXTRA_DOC, doc)
    }

    private lateinit var b: ActivityLegalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLegalBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        b.content.movementMethod = LinkMovementMethod.getInstance()

        for (t in TITLES) b.tabs.addTab(b.tabs.newTab().setText(t))
        val start = (savedInstanceState?.getInt(EXTRA_DOC) ?: intent.getIntExtra(EXTRA_DOC, DOC_TERMS))
            .coerceIn(0, FILES.size - 1)

        b.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = render(tab.position)
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        b.tabs.getTabAt(start)?.select()
        render(start)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(EXTRA_DOC, b.tabs.selectedTabPosition.coerceAtLeast(0))
    }

    private fun render(i: Int) {
        val html = try {
            assets.open(FILES[i]).bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            "<p>No se pudo cargar el documento.</p>"
        }
        b.content.text = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        b.scroll.scrollTo(0, 0)
    }
}
