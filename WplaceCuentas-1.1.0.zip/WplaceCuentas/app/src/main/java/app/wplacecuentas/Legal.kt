package app.wplacecuentas

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/** Enlaces externos de la app. */
object Links {
    const val FACEBOOK = "https://www.facebook.com/pageapanet"
    const val GITHUB = "https://github.com/Elgatocode"

    /** Página oficial de descargas y nuevas versiones. */
    const val UPDATES = "https://apannet.netlify.app/"
    const val UPDATES_LABEL = "apannet.netlify.app"

    fun open(ctx: Context, url: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No se pudo abrir el enlace", Toast.LENGTH_SHORT).show()
        }
    }

    fun versionName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }
}

/**
 * Registro local de la aceptación de los Términos y la Política de privacidad.
 * Va en un archivo aparte para que «Borrar todos mis datos» no elimine la constancia.
 * Si subes VERSION, la app volverá a pedir la aceptación.
 */
object Legal {
    const val VERSION = 1

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("wplace_legal", Context.MODE_PRIVATE)

    fun accepted(ctx: Context): Boolean = prefs(ctx).getInt("accepted", 0) >= VERSION

    fun accept(ctx: Context) {
        prefs(ctx).edit()
            .putInt("accepted", VERSION)
            .putLong("acceptedAt", System.currentTimeMillis())
            .apply()
    }
}
