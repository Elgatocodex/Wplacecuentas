package app.wplacecuentas

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import app.wplacecuentas.databinding.ItemAccountBinding

data class Row(
    val id: String,
    val name: String,
    val timer: String,
    val session: String?,
    val warn: Boolean,
    val bucket: Int,
    val hasTimer: Boolean,
    val px: Int,
    val maxPx: Int
)

class AccountAdapter(
    private val onOpen: (String) -> Unit,
    private val onEmpty: (String) -> Unit,
    private val onMenu: (String, View) -> Unit
) : ListAdapter<Row, AccountAdapter.VH>(Diff) {

    class VH(val b: ItemAccountBinding) : RecyclerView.ViewHolder(b.root)

    object Diff : DiffUtil.ItemCallback<Row>() {
        override fun areItemsTheSame(a: Row, b: Row) = a.id == b.id
        override fun areContentsTheSame(a: Row, b: Row) = a == b
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemAccountBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = getItem(position)
        val ctx = h.b.root.context
        h.b.name.text = r.name
        h.b.avatar.text = r.name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
        h.b.card.strokeColor = ContextCompat.getColor(ctx, if (r.bucket == 0) R.color.accent else R.color.outline)

        // Etiqueta de estado: LISTA / EN ESPERA (sin etiqueta si no hay temporizador)
        when (r.bucket) {
            0 -> {
                h.b.badge.visibility = View.VISIBLE
                h.b.badge.setText(R.string.status_ready)
                h.b.badge.setBackgroundResource(R.drawable.bg_pill_ready)
                h.b.badge.setTextColor(ContextCompat.getColor(ctx, R.color.accent))
            }
            2 -> {
                h.b.badge.visibility = View.VISIBLE
                h.b.badge.setText(R.string.status_wait)
                h.b.badge.setBackgroundResource(R.drawable.bg_pill_wait)
                h.b.badge.setTextColor(ContextCompat.getColor(ctx, R.color.muted))
            }
            else -> h.b.badge.visibility = View.GONE
        }

        if (r.hasTimer) {
            val max = r.maxPx.coerceAtLeast(1)
            h.b.progressRow.visibility = View.VISIBLE
            h.b.progress.max = max
            h.b.progress.setProgressCompat(r.px.coerceIn(0, max), false)
            h.b.pxText.text = "~${r.px}/${r.maxPx}"
        } else {
            h.b.progressRow.visibility = View.GONE
        }

        h.b.timer.text = r.timer
        h.b.timer.setTextColor(
            ContextCompat.getColor(
                ctx,
                when (r.bucket) {
                    0 -> R.color.accent
                    2 -> R.color.text
                    else -> R.color.muted
                }
            )
        )
        if (r.session == null) {
            h.b.session.visibility = View.GONE
        } else {
            h.b.session.visibility = View.VISIBLE
            h.b.session.text = r.session
            h.b.session.setTextColor(ContextCompat.getColor(ctx, if (r.warn) R.color.warn else R.color.muted))
        }
        h.b.card.setOnClickListener { onOpen(r.id) }
        h.b.btnOpen.setOnClickListener { onOpen(r.id) }
        h.b.btnEmpty.setOnClickListener { onEmpty(r.id) }
        h.b.menu.setOnClickListener { onMenu(r.id, it) }
    }
}
