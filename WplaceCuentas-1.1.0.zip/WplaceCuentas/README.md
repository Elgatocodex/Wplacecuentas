# WplaceCuentas

App Android (Kotlin + **GeckoView**, el motor de Firefox) para jugar en <https://wplace.live/> con varias cuentas de Google, usando una a la vez, y cambiar entre ellas con un toque.

- Cada cuenta tiene su **propio contexto de GeckoView** (cookies, localStorage y sesión separados). Cambiar de cuenta no cierra las demás.
- Temporizador por cuenta («Se acabaron los píxeles») con cuenta atrás, aviso local y lista ordenada (primero las que ya tienen píxeles).
- Todo se guarda **solo en el dispositivo**. No hay servidores, analíticas ni contraseñas guardadas: inicias sesión tú en la página de Google.
- **Aguanta el segundo plano**: puedes salir a Gmail a copiar un código y volver; la app te devuelve a la misma cuenta y a la misma página de Google, incluso si Android cerró la app por falta de memoria.
- **Legal incluido**: términos de servicio, política de privacidad y licencias dentro de la app (con aceptación al primer uso) y «Borrar todos mis datos».
- **Actualizaciones**: icono de descarga discreto en la cabecera que abre <https://apannet.netlify.app/>.
- La app **no automatiza nada**: no coloca píxeles ni hace clics. Solo lee si tu sesión sigue activa (una petición `GET` a `backend.wplace.live/me`) para avisarte de «Sesión caducada».
- Android 8.0 o superior. Interfaz en español, tema oscuro con acento verde.

## Estructura

```
.github/workflows/compilar-apk.yml   Compila el APK 1.1.0 en GitHub Actions (se entrega aparte del zip)
build.gradle.kts, settings.gradle.kts, gradle.properties
app/build.gradle.kts
app/src/main/
  AndroidManifest.xml
  assets/messaging/              Extensión interna (solo comprueba si hay sesión)
  java/app/wplacecuentas/
    Browser.kt                   GeckoRuntime + una GeckoSession aislada por cuenta
    BrowserActivity.kt           Navegador, barra inferior de cambio rápido, popups de login
    MainActivity.kt              Lista de cuentas, ajustes, prueba de login
    Data.kt                      Cuentas, ajustes y cálculo de píxeles/tiempos
    Alarms.kt                    Alarmas y notificaciones
    Legal.kt                     Enlaces (incl. actualizaciones) y registro de aceptación legal
    LegalActivity.kt             Visor de términos, privacidad y licencias
  assets/legal/                  terms.html, privacy.html, licenses.html (edítalos aquí)
  res/                           Layouts, tema, iconos, textos en español
design/ic_update.svg             Icono SVG original de «descargar actualización»
```

## 1) Subir el proyecto a GitHub desde el móvil

La forma más cómoda sin PC es **Termux** (instálalo desde F-Droid):

1. Descarga y guarda `WplaceCuentas.zip` en *Descargas*.
2. Crea un repositorio vacío en github.com (por ejemplo `WplaceCuentas`, sin README).
3. Crea un token: GitHub → *Settings → Developer settings → Personal access tokens → Tokens (classic)* → marca los permisos **repo** y **workflow**.
4. En Termux:

```bash
pkg update && pkg install -y git unzip
termux-setup-storage
cd ~
unzip ~/storage/downloads/WplaceCuentas.zip
cd WplaceCuentas
git init -b main
git add .
git commit -m "WplaceCuentas"
git remote add origin https://github.com/TU_USUARIO/WplaceCuentas.git
git push -u origin main
```

Cuando pida usuario escribe tu usuario de GitHub y como contraseña pega el **token**.

> Alternativa sin Termux: en la web de GitHub, *Add file → Create new file* y escribe la ruta completa (por ejemplo `app/src/main/res/values/colors.xml`) para crear las carpetas a mano. Funciona, pero son unos 35 archivos.

## 2) Compilar y descargar el APK

1. En tu repositorio abre la pestaña **Actions**. El workflow «Compilar APK 1.1.0» se lanza solo con cada `push` (o pulsa *Run workflow*).
2. Espera unos minutos (la primera vez descarga GeckoView, que pesa).
3. Entra en la ejecución terminada y baja a **Artifacts** → `WplaceCuentas-1.1.0-apk`. Se descarga un ZIP; descomprímelo y abre `WplaceCuentas-1.1.0.apk`.
4. Permite «instalar apps desconocidas» para tu navegador o gestor de archivos.

## 3) Primera prueba: ¿funciona el login de Google?

Menú ⋮ de la pantalla principal → **Probar login de Google**. Se abre `accounts.google.com` dentro de GeckoView:

- Si ves el cuadro para escribir el correo → el motor **no** es bloqueado. 
- Si aparece «Error 403: disallowed_useragent» → la app te lo avisa; sube `geckoVersion` en `gradle.properties` y recompila.

Al terminar la prueba se borran sus datos. Después: **Añadir cuenta** → inicia sesión → listo.

## Uso rápido

- **Barra inferior**: botones con tus cuentas (● verde = ya tiene píxeles), **Cuentas** (volver a la lista), **Se acabaron** (guarda la hora) y **Siguiente** (salta a la siguiente cuenta con píxeles).
- **Temporizador**: ⋮ → *Temporizador y ajustes* para cambiar minutos por píxel (por defecto 0,5 = 30 s), máximo de píxeles y a partir de cuántos píxeles avisar. Los píxeles mostrados son una estimación («~»).
- **Memoria**: GeckoView mantiene cargadas las últimas N páginas (por defecto 3) para que el cambio sea instantáneo y el mapa siga en su sitio; las demás se recargan al abrirlas (tu última posición la recuerda wplace).
- **Eliminar cuenta** borra cookies y datos de esa cuenta en el dispositivo.

## Novedades de la 1.1.0

- Diseño renovado: cabecera, resumen («listas / en espera»), tarjetas con etiqueta de estado y botón *Abrir*, pantalla vacía ilustrada, pie compacto.
- **Segundo plano**: la página de cada cuenta se guarda en disco y se restaura; los popups de login y las páginas cerradas por Android se recuperan al volver; Gecko se duerme cuando la app no está visible; se reabre la cuenta correcta tras un cierre del sistema.
- Barra de carga fina al abrir páginas.
- Avisos más puntuales (alarma exacta si Android lo permite).
- Términos, privacidad, licencias, aceptación al primer uso y borrado total de datos.

## Actualizaciones (importante: firma del APK)

Para que una versión nueva se instale **encima** de la anterior sin desinstalar, todos los APK deben ir firmados con la **misma clave**. El APK debug normal usa una clave distinta en cada máquina (y GitHub Actions genera una nueva en cada ejecución), así que las actualizaciones fallarían con «App no instalada».

1. Crea la clave **una sola vez** y guárdala bien (si la pierdes, nadie podrá actualizar sin desinstalar):

```bash
keytool -genkeypair -v -keystore wplace.jks -alias wplace -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 wplace.jks > wplace.jks.b64
```

2. En GitHub → *Settings → Secrets and variables → Actions* crea: `WPLACE_KEYSTORE_B64` (contenido de `wplace.jks.b64`), `WPLACE_KEYSTORE_PASSWORD`, `WPLACE_KEY_ALIAS` y `WPLACE_KEY_PASSWORD`.
3. El workflow `compilar-apk.yml` ya lee esos secrets y firma con tu clave. Si no los creas, compila igualmente pero con una clave temporal (valdrá para instalar, no para actualizar encima).
4. Cada vez que publiques una versión, sube `versionCode` (y `versionName`) en `app/build.gradle.kts` y sube el APK a <https://apannet.netlify.app/>.

## Textos legales

Están en `app/src/main/assets/legal/*.html`. Son una base sólida y fiel a lo que hace la app, pero **no son asesoramiento legal**: revísalos y, si quieres, añade tu país/jurisdicción y un correo de contacto. Si cambias el contenido de forma relevante, sube `Legal.VERSION` en `Legal.kt` y la app volverá a pedir la aceptación.

## Si falla la compilación

- *No se encuentra `org.mozilla.geckoview:...`*: mira las versiones en <https://maven.mozilla.org/?prefix=maven2/org/mozilla/geckoview/> y cambia `geckoVersion` (y `geckoArtifact` si tu móvil es de 32 bits: `geckoview-omni-armeabi-v7a`) en `gradle.properties`.
- Si falla, abre la ejecución en **Actions**: arriba, en el *Resumen*, aparece la causa del error (también se sube `build-log` como artifact). Copia ese bloque si necesitas ayuda.

---

Desarrollado por [facebook.com/pageapanet](https://www.facebook.com/pageapanet) · GitHub: [Elgatocode](https://github.com/Elgatocode)
