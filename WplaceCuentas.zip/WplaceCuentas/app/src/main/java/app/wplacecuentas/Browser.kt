package app.wplacecuentas

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebExtension

/**
 * Un único GeckoRuntime para todo el proceso y una GeckoSession por cuenta.
 * Cada sesión usa su propio "contextId" => cookies, localStorage y caché completamente separados.
 * Las sesiones viven aquí (no en la Activity), así que cambiar de cuenta no recarga la página.
 */
object Browser {
    private const val TAG = "WplaceCuentas"
    const val URL_WPLACE = "https://wplace.live/"
    private const val EXT_URI = "resource://android/assets/messaging/"
    private const val EXT_ID = "messaging@wplacecuentas.app"

    private var rt: GeckoRuntime? = null
    private var extension: WebExtension? = null
    private val sessions = HashMap<String, GeckoSession>()
    private val popups = HashMap<String, GeckoSession>()
    private val backMap = HashMap<String, Boolean>()
    private val lru = LinkedHashSet<String>()
    private val main = Handler(Looper.getMainLooper())

    var onGoogleBlocked: (() -> Unit)? = null
    var onPopup: ((GeckoSession) -> Unit)? = null
    var onPopupClosed: (() -> Unit)? = null
    var onSessionLost: ((String) -> Unit)? = null
    var onSessionState: ((String) -> Unit)? = null

    private fun contextFor(id: String) = "acc$id"

    // ---------- Runtime ----------
    fun runtime(ctx: Context): GeckoRuntime {
        rt?.let { return it }
        val settings = GeckoRuntimeSettings.Builder()
            .javaScriptEnabled(true)
            .remoteDebuggingEnabled(false)
            .aboutConfigEnabled(false)
            .build()
        val r = GeckoRuntime.create(ctx.applicationContext, settings)
        rt = r
        installExtension(r)
        return r
    }

    private fun <T> GeckoResult<T>.onDone(ok: (T?) -> Unit, err: (Throwable) -> Unit) {
        this.accept(
            GeckoResult.Consumer<T> { value -> ok(value) },
            GeckoResult.Consumer<Throwable> { e -> err(e ?: RuntimeException("error desconocido")) }
        )
    }

    private fun installExtension(r: GeckoRuntime) {
        r.webExtensionController.ensureBuiltIn(EXT_URI, EXT_ID).onDone(
            { ext ->
                if (ext != null) {
                    extension = ext
                    for ((id, s) in sessions) attachExt(s, id)
                }
            },
            { e -> Log.e(TAG, "No se pudo instalar la extensión interna", e) }
        )
    }

    private fun attachExt(s: GeckoSession, id: String) {
        val ext = extension ?: return
        try {
            s.webExtensionController.setMessageDelegate(
                ext,
                object : WebExtension.MessageDelegate {
                    override fun onMessage(
                        nativeApp: String,
                        message: Any,
                        sender: WebExtension.MessageSender
                    ): GeckoResult<Any>? {
                        handleMessage(id, message)
                        return null
                    }
                },
                "browser"
            )
        } catch (e: Exception) {
            Log.e(TAG, "setMessageDelegate", e)
        }
    }

    private fun handleMessage(id: String, message: Any) {
        val json = message as? JSONObject ?: return
        if (json.optString("type") != "auth") return
        when (json.optString("state")) {
            "ok" -> AccountStore.update(id) {
                it.copy(sessionState = SessionState.OK, loggedInEver = true)
            }
            "out" -> AccountStore.update(id) {
                it.copy(sessionState = if (it.loggedInEver) SessionState.EXPIRED else SessionState.LOGGED_OUT)
            }
            else -> return
        }
        onSessionState?.invoke(id)
    }

    // ---------- Sesiones ----------
    fun sessionFor(ctx: Context, id: String, startUrl: String): GeckoSession {
        val s = sessions[id] ?: create(ctx, id, startUrl)
        touch(id)
        return s
    }

    private fun create(ctx: Context, id: String, startUrl: String): GeckoSession {
        val r = runtime(ctx)
        val settings = GeckoSessionSettings.Builder()
            .contextId(contextFor(id))   // <- aislamiento total por cuenta
            .build()
        val s = GeckoSession(settings)
        wire(s, id, settings, false)
        s.open(r)
        sessions[id] = s
        attachExt(s, id)
        s.loadUri(startUrl)
        return s
    }

    private fun wire(s: GeckoSession, id: String, settings: GeckoSessionSettings, isPopup: Boolean) {
        var lastUrl = ""
        val backKey = if (isPopup) "$id#popup" else id

        s.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                if (lastUrl.contains("accounts.google.com") && title != null &&
                    (title.contains("403") || title.contains("disallowed", ignoreCase = true))
                ) {
                    onGoogleBlocked?.invoke()
                }
            }

            override fun onCloseRequest(session: GeckoSession) {
                if (isPopup) closePopup(id)
            }

            override fun onCrash(session: GeckoSession) {
                if (!isPopup) lost(id) else closePopup(id)
            }

            override fun onKill(session: GeckoSession) {
                if (!isPopup) lost(id) else closePopup(id)
            }
        }

        s.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                lastUrl = url
                if (url.contains("disallowed_useragent")) onGoogleBlocked?.invoke()
            }
        }

        s.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                backMap[backKey] = canGoBack
            }

            // Ventanas emergentes (p. ej. "Iniciar sesión con Google" en popup)
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                if (isPopup) return null
                return openPopup(id, settings)
            }
        }
    }

    private fun openPopup(id: String, settings: GeckoSessionSettings): GeckoResult<GeckoSession> {
        popups.remove(id)?.let { runCatching { it.close() } }
        val p = GeckoSession(settings)
        wire(p, id, settings, true)
        popups[id] = p
        main.post { onPopup?.invoke(p) }
        return GeckoResult.fromValue(p)
    }

    fun closePopup(id: String) {
        val p = popups.remove(id) ?: return
        backMap.remove("$id#popup")
        onPopupClosed?.invoke()
        runCatching { p.close() }
    }

    private fun lost(id: String) {
        close(id)
        lru.remove(id)
        main.post { onSessionLost?.invoke(id) }
    }

    /** Mantiene como máximo N páginas cargadas (las más recientes). Las demás se recargan al abrirlas. */
    private fun touch(id: String) {
        lru.remove(id)
        lru.add(id)
        val max = AccountStore.config().pagesInMemory.coerceAtLeast(1)
        while (lru.size > max) {
            val victim = lru.firstOrNull { it != id } ?: break
            lru.remove(victim)
            close(victim)
        }
    }

    private fun close(id: String) {
        popups.remove(id)?.let { runCatching { it.close() } }
        sessions.remove(id)?.let { runCatching { it.close() } }
        backMap.remove(id)
        backMap.remove("$id#popup")
    }

    /** Elimina la sesión: cierra la página y borra cookies/almacenamiento de esa cuenta. */
    fun delete(ctx: Context, id: String) {
        close(id)
        lru.remove(id)
        try {
            runtime(ctx).storageController.clearDataForSessionContext(contextFor(id))
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo borrar el almacenamiento", e)
        }
    }

    fun canGoBack(id: String) = backMap[id] == true

    fun goBack(id: String) {
        sessions[id]?.goBack(true)
    }
}
