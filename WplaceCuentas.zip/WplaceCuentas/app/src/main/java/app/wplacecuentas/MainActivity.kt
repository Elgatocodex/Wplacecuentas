package app.wplacecuentas

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import app.wplacecuentas.databinding.ActivityMainBinding
import app.wplacecuentas.databinding.DialogSettingsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {
    private companion object {
        const val URL_FACEBOOK = "https://www.facebook.com/pageapanet"
        const val URL_GITHUB = "https://github.com/Elgatocode"
    }

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: AccountAdapter
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }
    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        adapter = AccountAdapter(::openAccount, ::markEmpty, ::showMenu)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.list.itemAnimator = null

        b.fabAdd.setOnClickListener { addAccount() }
        b.btnFacebook.setOnClickListener { openUrl(URL_FACEBOOK) }
        b.btnGithub.setOnClickListener { openUrl(URL_GITHUB) }
        b.toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_settings -> { showSettings(); true }
                R.id.action_test -> { startTest(); true }
                R.id.action_about -> { showAbout(); true }
                else -> false
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        Alarms.rescheduleAll(this)
        Browser.onSessionState = { refresh() }
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        Browser.onSessionState = null
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir el enlace", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.app_name))
            .setMessage(getString(R.string.about_message))
            .setPositiveButton("Facebook") { _, _ -> openUrl(URL_FACEBOOK) }
            .setNeutralButton("GitHub") { _, _ -> openUrl(URL_GITHUB) }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun refresh() {
        val c = AccountStore.config()
        val now = System.currentTimeMillis()
        val rows = Timers.sorted(AccountStore.all(), c, now).map { a ->
            Row(
                id = a.id,
                name = a.name,
                timer = Timers.timerLine(a, c, now),
                session = Timers.sessionLine(a),
                warn = a.sessionState == SessionState.EXPIRED,
                bucket = Timers.bucket(a, c, now),
                hasTimer = Timers.hasTimer(a),
                px = Timers.pixels(a, c, now) ?: 0,
                maxPx = c.maxPixels
            )
        }
        adapter.submitList(rows)
        b.emptyText.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }

    // ---------- Acciones ----------
    private fun openAccount(id: String) {
        startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_ID, id))
    }

    private fun addAccount() {
        val names = AccountStore.all().map { it.name }.toSet()
        var n = AccountStore.all().size + 1
        while ("Cuenta $n" in names) n++
        val a = AccountStore.add("Cuenta $n")
        refresh()
        openAccount(a.id)
    }

    private fun markEmpty(id: String) {
        val a = AccountStore.update(id) { it.copy(emptyAt = System.currentTimeMillis()) } ?: return
        Alarms.schedule(this, a)
        val c = AccountStore.config()
        val rem = Timers.remaining(a, c, System.currentTimeMillis())
        Toast.makeText(this, "${a.name}: te aviso en ${Timers.fmt(rem)}", Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun showMenu(id: String, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menuInflater.inflate(R.menu.account_menu, pm.menu)
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.rename -> rename(id)
                R.id.clear_timer -> clearTimer(id)
                R.id.delete -> confirmDelete(id)
            }
            true
        }
        pm.show()
    }

    private fun rename(id: String) {
        val a = AccountStore.get(id) ?: return
        val input = EditText(this).apply {
            setText(a.name)
            setSelection(text.length)
            setSingleLine()
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Nombre de la cuenta")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) {
                    AccountStore.update(id) { it.copy(name = n) }
                    refresh()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun clearTimer(id: String) {
        val a = AccountStore.update(id) { it.copy(emptyAt = 0L) } ?: return
        Alarms.cancel(this, a.id)
        refresh()
    }

    private fun confirmDelete(id: String) {
        val a = AccountStore.get(id) ?: return
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar «${a.name}»")
            .setMessage("Se borrará la sesión de esta cuenta (cookies y datos de wplace y de Google) en este dispositivo. No se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                Alarms.cancel(this, id)
                Browser.delete(this, id)
                AccountStore.remove(id)
                refresh()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startTest() {
        startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_TEST, true))
    }

    private fun showSettings() {
        val c = AccountStore.config()
        val d = DialogSettingsBinding.inflate(layoutInflater)
        d.inMpp.setText(c.minutesPerPixel.toString())
        d.inMax.setText(c.maxPixels.toString())
        d.inNotify.setText(c.notifyAt.toString())
        d.inPages.setText(c.pagesInMemory.toString())
        MaterialAlertDialogBuilder(this)
            .setTitle("Temporizador y ajustes")
            .setView(d.root)
            .setPositiveButton("Guardar") { _, _ ->
                val mpp = d.inMpp.text.toString().replace(',', '.').toDoubleOrNull()
                val max = d.inMax.text.toString().toIntOrNull()
                val notify = d.inNotify.text.toString().toIntOrNull()
                val pages = d.inPages.text.toString().toIntOrNull()
                if (mpp == null || mpp <= 0.0 || max == null || max < 1 ||
                    notify == null || notify < 1 || pages == null || pages < 1
                ) {
                    Toast.makeText(this, "Valores no válidos, no se guardó nada", Toast.LENGTH_LONG).show()
                } else {
                    AccountStore.saveConfig(Config(mpp, max, notify.coerceAtMost(max), pages))
                    Alarms.rescheduleAll(this)
                    refresh()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
