package app.wplacecuentas

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // OJO: GeckoView lanza procesos hijos que también ejecutan esto; aquí solo cosas ligeras.
        AccountStore.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "Píxeles listos", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Avisa cuando una cuenta ya tiene píxeles otra vez"
        nm.createNotificationChannel(ch)
    }

    companion object {
        const val CHANNEL_ID = "pixeles"
    }
}
