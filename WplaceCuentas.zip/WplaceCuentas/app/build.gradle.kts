plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val geckoArtifact = providers.gradleProperty("geckoArtifact").getOrElse("geckoview-omni-arm64-v8a")
val geckoVersion = providers.gradleProperty("geckoVersion").getOrElse("140.0.20250707120347")

base {
    archivesName.set("WplaceCuentas")
}

android {
    namespace = "app.wplacecuentas"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.wplacecuentas"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { viewBinding = true }

    packaging { jniLibs { useLegacyPackaging = true } }
    androidResources { noCompress += "ja" }
}

dependencies {
    implementation("org.mozilla.geckoview:$geckoArtifact:$geckoVersion")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
}
