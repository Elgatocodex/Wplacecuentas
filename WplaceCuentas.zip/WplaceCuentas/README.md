# WplaceCuentas

App Android (Kotlin + **GeckoView**, el motor de Firefox) para jugar en <https://wplace.live/> con varias cuentas de Google, usando una a la vez, y cambiar entre ellas con un toque.

- Cada cuenta tiene su **propio contexto de GeckoView** (cookies, localStorage y sesión separados). Cambiar de cuenta no cierra las demás.
- Temporizador por cuenta («Se acabaron los píxeles») con cuenta atrás, aviso local y lista ordenada (primero las que ya tienen píxeles).
- Todo se guarda **solo en el dispositivo**. No hay servidores, analíticas ni contraseñas guardadas: inicias sesión tú en la página de Google.
- La app **no automatiza nada**: no coloca píxeles ni hace clics. Solo lee si tu sesión sigue activa (una petición `GET` a `backend.wplace.live/me`) para avisarte de «Sesión caducada».
- Android 8.0 o superior. Interfaz en español, tema oscuro con acento verde.

## Estructura

```
.github/workflows/build.yml      Compila el APK debug en GitHub Actions
build.gradle.kts, settings.gradle.kts, gradle.properties
app/build.gradle.kts
app/src/main/
  AndroidManifest.xml
  assets/messaging/              Extensión interna (solo comprueba si hay sesión)
  java/app/wplacecuentas/
    Browser.kt                   GeckoRuntime + una GeckoSession aislada por cuenta
    BrowserActivity.kt           Navegador, barra inferior de cambio rápido, popups de login
    MainActivity.kt              Lista de cuentas, ajustes, prueba de login
    Data.kt                      Cuentas, ajustes y cálculo de píxeles/tiempos
    Alarms.kt                    Alarmas y notificaciones
  res/                           Layouts, tema, iconos, textos en español
```

## 1) Subir el proyecto a GitHub desde el móvil

La forma más cómoda sin PC es **Termux** (instálalo desde F-Droid):

1. Descarga y guarda `WplaceCuentas.zip` en *Descargas*.
2. Crea un repositorio vacío en github.com (por ejemplo `WplaceCuentas`, sin README).
3. Crea un token: GitHub → *Settings → Developer settings → Personal access tokens → Tokens (classic)* → marca los permisos **repo** y **workflow**.
4. En Termux:

```bash
pkg update && pkg install -y git unzip
termux-setup-storage
cd ~
unzip ~/storage/downloads/WplaceCuentas.zip
cd WplaceCuentas
git init -b main
git add .
git commit -m "WplaceCuentas"
git remote add origin https://github.com/TU_USUARIO/WplaceCuentas.git
git push -u origin main
```

Cuando pida usuario escribe tu usuario de GitHub y como contraseña pega el **token**.

> Alternativa sin Termux: en la web de GitHub, *Add file → Create new file* y escribe la ruta completa (por ejemplo `app/src/main/res/values/colors.xml`) para crear las carpetas a mano. Funciona, pero son unos 35 archivos.

## 2) Compilar y descargar el APK

1. En tu repositorio abre la pestaña **Actions**. El workflow «Compilar APK debug» se lanza solo con cada `push` (o pulsa *Run workflow*).
2. Espera unos minutos (la primera vez descarga GeckoView, que pesa).
3. Entra en la ejecución terminada y baja a **Artifacts** → `WplaceCuentas-debug-apk`. Se descarga un ZIP; descomprímelo y abre `app-debug.apk`.
4. Permite «instalar apps desconocidas» para tu navegador o gestor de archivos.

## 3) Primera prueba: ¿funciona el login de Google?

Menú ⋮ de la pantalla principal → **Probar login de Google**. Se abre `accounts.google.com` dentro de GeckoView:

- Si ves el cuadro para escribir el correo → el motor **no** es bloqueado. 
- Si aparece «Error 403: disallowed_useragent» → la app te lo avisa; sube `geckoVersion` en `gradle.properties` y recompila.

Al terminar la prueba se borran sus datos. Después: **Añadir cuenta** → inicia sesión → listo.

## Uso rápido

- **Barra inferior**: botones con tus cuentas (● verde = ya tiene píxeles), **Cuentas** (volver a la lista), **Se acabaron** (guarda la hora) y **Siguiente** (salta a la siguiente cuenta con píxeles).
- **Temporizador**: ⋮ → *Temporizador y ajustes* para cambiar minutos por píxel (por defecto 0,5 = 30 s), máximo de píxeles y a partir de cuántos píxeles avisar. Los píxeles mostrados son una estimación («~»).
- **Memoria**: GeckoView mantiene cargadas las últimas N páginas (por defecto 3) para que el cambio sea instantáneo y el mapa siga en su sitio; las demás se recargan al abrirlas (tu última posición la recuerda wplace).
- **Eliminar cuenta** borra cookies y datos de esa cuenta en el dispositivo.

## Si falla la compilación

- *No se encuentra `org.mozilla.geckoview:...`*: mira las versiones en <https://maven.mozilla.org/?prefix=maven2/org/mozilla/geckoview/> y cambia `geckoVersion` (y `geckoArtifact` si tu móvil es de 32 bits: `geckoview-omni-armeabi-v7a`) en `gradle.properties`.
- Si falla, abre la ejecución en **Actions**: arriba, en el *Resumen*, aparece la causa del error (también se sube `build-log` como artifact). Copia ese bloque si necesitas ayuda.

---

Desarrollado por [facebook.com/pageapanet](https://www.facebook.com/pageapanet) · GitHub: [Elgatocode](https://github.com/Elgatocode)
