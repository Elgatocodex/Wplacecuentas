# WplaceCuentas

[![Licencia: MIT](https://img.shields.io/badge/licencia-MIT-4ade80.svg)](LICENSE)

Aplicación Android **libre y de código abierto** para jugar en <https://wplace.live/> con varias cuentas de Google, usando una a la vez, y cambiar entre ellas con un toque. Usa **GeckoView** (el motor de Firefox) para que el inicio de sesión de Google funcione.

- Código fuente: <https://github.com/Elgatocodex/Wplacecuentas>
- Descargas y actualizaciones: <https://apannet.netlify.app/>
- Problemas y sugerencias: <https://github.com/Elgatocodex/Wplacecuentas/issues>

## Qué hace

- **Perfiles aislados**: cada cuenta tiene sus propias cookies, localStorage y sesión (un contexto de GeckoView por cuenta). Cambiar de cuenta no cierra las demás.
- **Cambio rápido**: barra inferior con una tecla por cuenta, botón «Siguiente» (salta a la siguiente cuenta con píxeles) y páginas que siguen cargadas en segundo plano.
- **Temporizador por cuenta**: «Se acabaron los píxeles» guarda la hora; la app calcula la recarga (minutos por píxel y máximo configurables), muestra cuenta atrás y barra de progreso, y avisa con una notificación local.
- **Sesión caducada**: lo indica en la lista.
- **Privacidad**: todo se guarda solo en el dispositivo. Sin servidores, sin analíticas, sin contraseñas guardadas.
- **No automatiza el juego**: no coloca píxeles ni hace clics.
- Interfaz en español, tema oscuro con acento verde. Android 8.0 o superior.

## Novedades de la 1.1.0

- Protecciones contra cierres al iniciar sesión con Gmail/Google (callbacks protegidos, autorrelleno del sistema desactivado, enlaces `intent:`/`market:` bloqueados, plan B para ventanas emergentes, sin bucles de recreación).
- Informe local de fallos: si algo se cierra, al abrir la app aparece un informe que puedes copiar y enviar.
- Nuevo diseño: tarjetas con avatar y barra de progreso, resumen en la cabecera, panel inferior redondeado, barra de carga y botón de recargar.
- Pantalla «Acerca de y legal»: términos, privacidad, cookies, licencias, enlace de descargas y «Borrar todos los datos».
- Aceptación de términos en el primer arranque.

## Compilar con GitHub Actions (sin PC)

El workflow **no va dentro de este ZIP**: se entrega aparte como `build.yml` para que no haya dos copias.

1. En tu repositorio sube `wplacecuentas.zip` a la raíz.
2. Crea `.github/workflows/build.yml` con el contenido del `build.yml` entregado aparte.
3. Pestaña **Actions** → «Compilar wplacecuentas» (se lanza con cada `push`, o *Run workflow*). El workflow descomprime el ZIP más reciente de la raíz.
4. Al terminar, descarga el APK en **Artifacts** (`wplacecuentas-apk`).

Si prefieres subir el proyecto suelto (sin ZIP), pon su contenido en la raíz y el mismo workflow lo detecta.

La versión de GeckoView está fijada en `gradle.properties` (`geckoVersion`). Las versiones disponibles están en <https://maven.mozilla.org/?prefix=maven2/org/mozilla/geckoview/>. Móviles de 32 bits: usa `geckoview-omni-armeabi-v7a` en `geckoArtifact`.

## Estructura

```
LICENSE                       Licencia MIT
docs/                         Términos, privacidad, cookies y licencias (mismo texto que la app)
app/src/main/
  assets/legal/               Textos legales mostrados dentro de la app
  assets/messaging/           Extensión interna (solo comprueba si la sesión sigue activa)
  java/app/wplacecuentas/     Código Kotlin (Browser, actividades, datos, alarmas, legal)
  res/                        Layouts, tema, iconos, textos
```

## Documentos legales

- [Términos y condiciones](docs/TERMINOS.md)
- [Política de privacidad](docs/PRIVACIDAD.md)
- [Política de cookies](docs/COOKIES.md)
- [Licencias y avisos de terceros](docs/LICENCIAS.md)

> Estos textos son plantillas razonables para un proyecto personal de código abierto, no asesoramiento jurídico. Si distribuyes la app a mucha gente o la monetizas, revísalos con un profesional y ajusta la jurisdicción y los datos de contacto.

## Contribuir

Los *issues* y *pull requests* son bienvenidos. Al contribuir aceptas que tu aportación se publique bajo la licencia MIT.

## Aviso

Proyecto independiente, no afiliado a wplace.live, Google, Gmail, Mozilla ni Firefox. Cada usuario es responsable de cumplir las normas de esos servicios, incluidas las relativas al uso de varias cuentas.
