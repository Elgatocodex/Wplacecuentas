package app.wplacecuentas

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri

object Alarms {
    private const val ACTION = "app.wplacecuentas.ALARM"

    private fun pending(ctx: Context, id: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION)
            .setData(Uri.parse("wplace://alarm/$id"))
            .putExtra("id", id)
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(ctx: Context, a: Account) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, a.id)
        am.cancel(pi)
        if (!Timers.hasTimer(a)) return
        val at = Timers.readyAt(a, AccountStore.config())
        if (at > System.currentTimeMillis()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, id: String) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, id))
        ctx.getSystemService(NotificationManager::class.java).cancel(id.hashCode())
    }

    fun rescheduleAll(ctx: Context) {
        AccountStore.all().forEach { schedule(ctx, it) }
    }
}

object Notifier {
    fun pixelsReady(ctx: Context, a: Account, px: Int, c: Config) {
        val open = Intent(ctx, BrowserActivity::class.java)
            .putExtra(BrowserActivity.EXTRA_ID, a.id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            ctx, a.id.hashCode(), open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, App.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle("${a.name}: ¡ya hay píxeles!")
            .setContentText("Tiene ~$px/${c.maxPixels} píxeles. Toca para abrirla.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(a.id.hashCode(), n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val a = AccountStore.get(id) ?: return
        val c = AccountStore.config()
        val now = System.currentTimeMillis()
        if (Timers.remaining(a, c, now) > 5000L) {
            Alarms.schedule(ctx, a) // el temporizador cambió: reprogramar
            return
        }
        Notifier.pixelsReady(ctx, a, Timers.pixels(a, c, now) ?: c.maxPixels, c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Alarms.rescheduleAll(ctx)
    }
}
