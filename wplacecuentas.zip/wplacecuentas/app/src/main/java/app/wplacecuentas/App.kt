package app.wplacecuentas

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.util.Log
import java.io.File

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // OJO: GeckoView lanza procesos hijos que también ejecutan esto; aquí solo cosas ligeras.
        AccountStore.init(this)
        Crumbs.init(this)
        installCrashReporter()
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "Píxeles listos", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Avisa cuando una cuenta ya tiene píxeles otra vez"
        nm.createNotificationChannel(ch)
    }

    fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    /** Guarda el error en un archivo local para poder verlo/copiarlo en el siguiente arranque. */
    private fun installCrashReporter() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val r = "WplaceCuentas ${versionName()}\n" +
                    "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER} ${Build.MODEL}\n\n" +
                    Log.getStackTraceString(e) +
                    "\n--- Últimos eventos ---\n" + Crumbs.dump()
                File(filesDir, "crash.txt").writeText(r)
            } catch (x: Throwable) {
                // no hacer nada: no podemos empeorar el fallo
            }
            prev?.uncaughtException(t, e)
        }
    }

    companion object {
        const val CHANNEL_ID = "pixeles"
    }
}
