package app.wplacecuentas

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object SessionState {
    const val UNKNOWN = 0
    const val OK = 1
    const val EXPIRED = 2
    const val LOGGED_OUT = 3
}

data class Account(
    val id: String,
    val name: String,
    val emptyAt: Long = 0L,            // 0 = sin temporizador
    val loggedInEver: Boolean = false,
    val sessionState: Int = SessionState.UNKNOWN
)

data class Config(
    val minutesPerPixel: Double,
    val maxPixels: Int,
    val notifyAt: Int,
    val pagesInMemory: Int
)

/** Todo se guarda solo en el dispositivo (SharedPreferences). Nunca contraseñas. */
object AccountStore {
    private lateinit var prefs: SharedPreferences
    private val accounts = mutableListOf<Account>()

    @Synchronized
    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("wplace_cuentas", Context.MODE_PRIVATE)
        accounts.clear()
        try {
            val arr = JSONArray(prefs.getString("accounts", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                accounts.add(
                    Account(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        emptyAt = o.optLong("emptyAt", 0L),
                        loggedInEver = o.optBoolean("loggedInEver", false),
                        sessionState = o.optInt("sessionState", SessionState.UNKNOWN)
                    )
                )
            }
        } catch (e: Exception) {
            // datos corruptos: empezamos vacío
        }
    }

    private fun persist() {
        val arr = JSONArray()
        for (a in accounts) {
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("name", a.name)
                    .put("emptyAt", a.emptyAt)
                    .put("loggedInEver", a.loggedInEver)
                    .put("sessionState", a.sessionState)
            )
        }
        prefs.edit().putString("accounts", arr.toString()).apply()
    }

    @Synchronized fun all(): List<Account> = accounts.toList()

    @Synchronized fun get(id: String): Account? = accounts.firstOrNull { it.id == id }

    @Synchronized
    fun add(name: String): Account {
        val a = Account(UUID.randomUUID().toString().replace("-", ""), name)
        accounts.add(a)
        persist()
        return a
    }

    @Synchronized
    fun update(id: String, f: (Account) -> Account): Account? {
        val i = accounts.indexOfFirst { it.id == id }
        if (i < 0) return null
        val n = f(accounts[i])
        accounts[i] = n
        persist()
        return n
    }

    @Synchronized
    fun remove(id: String) {
        accounts.removeAll { it.id == id }
        persist()
    }

    fun legalVersion(): Int = prefs.getInt("legal", 0)

    fun acceptLegal(v: Int) {
        prefs.edit().putInt("legal", v).apply()
    }

    @Synchronized
    fun clearAll() {
        accounts.clear()
        persist()
    }

    fun config(): Config {
        val mpp = prefs.getString("mpp", "0.5")?.toDoubleOrNull()?.takeIf { it > 0.0 } ?: 0.5
        val max = prefs.getInt("max", 30).coerceAtLeast(1)
        val notify = prefs.getInt("notify", 30).coerceIn(1, max)
        val pages = prefs.getInt("pages", 3).coerceAtLeast(1)
        return Config(mpp, max, notify, pages)
    }

    fun saveConfig(c: Config) {
        prefs.edit()
            .putString("mpp", c.minutesPerPixel.toString())
            .putInt("max", c.maxPixels)
            .putInt("notify", c.notifyAt.coerceIn(1, c.maxPixels))
            .putInt("pages", c.pagesInMemory)
            .apply()
    }
}

object Timers {
    fun msPerPixel(c: Config): Long = (c.minutesPerPixel * 60_000.0).toLong().coerceAtLeast(1000L)

    fun hasTimer(a: Account) = a.emptyAt > 0L

    private fun target(c: Config) = c.notifyAt.coerceIn(1, c.maxPixels)

    fun pixels(a: Account, c: Config, now: Long): Int? {
        if (!hasTimer(a)) return null
        val n = ((now - a.emptyAt).coerceAtLeast(0L) / msPerPixel(c)).coerceAtMost(c.maxPixels.toLong())
        return n.toInt()
    }

    fun readyAt(a: Account, c: Config): Long =
        if (!hasTimer(a)) 0L else a.emptyAt + target(c).toLong() * msPerPixel(c)

    fun remaining(a: Account, c: Config, now: Long): Long =
        if (!hasTimer(a)) 0L else (readyAt(a, c) - now).coerceAtLeast(0L)

    /** 0 = con píxeles (temporizador cumplido), 1 = sin temporizador, 2 = esperando recarga */
    fun bucket(a: Account, c: Config, now: Long): Int = when {
        !hasTimer(a) -> 1
        remaining(a, c, now) == 0L -> 0
        else -> 2
    }

    fun sorted(list: List<Account>, c: Config, now: Long): List<Account> =
        list.sortedWith(
            compareBy<Account> { bucket(it, c, now) }.thenBy {
                when (bucket(it, c, now)) {
                    0 -> -(pixels(it, c, now) ?: 0).toLong()
                    2 -> remaining(it, c, now)
                    else -> 0L
                }
            }
        )

    fun fmt(ms: Long): String {
        val s = (ms + 999) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    fun timerLine(a: Account, c: Config, now: Long): String {
        if (!hasTimer(a)) return "Sin temporizador"
        val px = pixels(a, c, now) ?: 0
        val rem = remaining(a, c, now)
        return if (rem == 0L) "✅ Píxeles disponibles · ~$px/${c.maxPixels}"
        else "⏳ Listo en ${fmt(rem)} · ~$px/${c.maxPixels} píxeles"
    }

    fun sessionLine(a: Account): String? = when (a.sessionState) {
        SessionState.EXPIRED -> "⚠ Sesión caducada, vuelve a iniciar sesión"
        SessionState.OK -> "Sesión iniciada"
        SessionState.LOGGED_OUT -> "Sin sesión · toca para iniciar sesión"
        else -> if (a.loggedInEver) null else "Toca para abrir e iniciar sesión"
    }
}

/** Registro técnico local (nunca sale del dispositivo): últimos eventos para diagnosticar cierres. */
object Crumbs {
    private lateinit var p: SharedPreferences
    private val items = ArrayDeque<String>()

    @Synchronized
    fun init(ctx: Context) {
        p = ctx.applicationContext.getSharedPreferences("wplace_diag", Context.MODE_PRIVATE)
        items.clear()
        (p.getString("crumbs", "") ?: "").split("\n").filter { it.isNotBlank() }.forEach { items.addLast(it) }
    }

    @Synchronized
    fun add(msg: String) {
        if (!::p.isInitialized) return
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        items.addLast("$t $msg")
        while (items.size > 25) items.removeFirst()
        p.edit().putString("crumbs", items.joinToString("\n")).apply()
    }

    @Synchronized fun dump(): String = items.joinToString("\n")

    @Synchronized
    fun clear() {
        items.clear()
        if (::p.isInitialized) p.edit().remove("crumbs").apply()
    }

    /** true mientras el navegador está en primer plano; si al arrancar sigue true, hubo un cierre inesperado. */
    fun setActive(v: Boolean) {
        if (::p.isInitialized) p.edit().putBoolean("active", v).commit()
    }

    fun wasActive(): Boolean = ::p.isInitialized && p.getBoolean("active", false)
}
