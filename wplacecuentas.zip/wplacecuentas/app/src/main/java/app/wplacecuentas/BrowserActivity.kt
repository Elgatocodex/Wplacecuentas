package app.wplacecuentas

import android.app.NotificationManager
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import app.wplacecuentas.databinding.ActivityBrowserBinding
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.mozilla.geckoview.GeckoSession

class BrowserActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_ID = "id"
        const val EXTRA_TEST = "test"
        const val TEST_ID = "prueba"
        private const val TAG = "WplaceCuentas"
    }

    private lateinit var b: ActivityBrowserBinding
    private var currentId = ""
    private var testMode = false
    private var blockedShown = false
    private val chips = LinkedHashMap<String, MaterialButton>()
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            try { refreshBar() } catch (e: Throwable) { Log.e(TAG, "refreshBar", e) }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityBrowserBinding.inflate(layoutInflater)
        setContentView(b.root)

        // El autorrelleno del sistema con campos de Google/Gmail es una causa conocida de cierres: desactivado.
        b.gecko.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        b.popupGecko.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS

        try {
            Browser.runtime(this) // arranca Gecko
        } catch (e: Throwable) {
            Log.e(TAG, "Gecko no arrancó", e)
            Crumbs.add("ERR Gecko no arrancó ${e.javaClass.simpleName}")
            Toast.makeText(this, "No se pudo iniciar el navegador integrado", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        b.btnList.setOnClickListener { goToList() }
        b.btnEmpty.setOnClickListener { markEmpty() }
        b.btnNext.setOnClickListener { goNext() }
        b.btnReload.setOnClickListener { Browser.reload(currentId) }
        b.btnClosePopup.setOnClickListener { Browser.closePopup(currentId) }
        b.btnEndTest.setOnClickListener { finish() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    b.popupLayer.visibility == View.VISIBLE -> Browser.closePopup(currentId)
                    Browser.canGoBack(currentId) -> Browser.goBack(currentId)
                    else -> goToList()
                }
            }
        })

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Crumbs.setActive(true)
        Browser.onGoogleBlocked = { showBlocked() }
        Browser.onPopup = { p -> showPopup(p, 0) }
        Browser.onPopupClosed = { hidePopup() }
        Browser.onSessionState = { refreshBar() }
        Browser.onProgress = { id, p ->
            if (id == currentId) {
                b.progress.visibility = if (p in 1..99) View.VISIBLE else View.GONE
                b.progress.progress = p
            }
        }
        Browser.onSessionLost = { id, giveUp ->
            if (id == currentId && !testMode && !isFinishing) {
                if (giveUp) {
                    Toast.makeText(this, "El navegador se cerró varias veces seguidas. Toca ⟳ para reintentar.", Toast.LENGTH_LONG).show()
                } else {
                    show(id)
                }
            }
        }
        getSystemService(NotificationManager::class.java).cancel(currentId.hashCode())
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        Crumbs.setActive(false)
        handler.removeCallbacks(ticker)
        Browser.onGoogleBlocked = null
        Browser.onPopup = null
        Browser.onPopupClosed = null
        Browser.onSessionState = null
        Browser.onProgress = null
        Browser.onSessionLost = null
    }

    override fun onDestroy() {
        runCatching { b.popupGecko.releaseSession() }
        runCatching { b.gecko.releaseSession() }
        if (isFinishing && testMode) Browser.delete(this, TEST_ID)
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)

    // ---------- Navegación entre cuentas ----------
    private fun handleIntent(i: Intent?) {
        testMode = i?.getBooleanExtra(EXTRA_TEST, false) == true
        if (testMode) {
            b.accountBar.visibility = View.GONE
            b.testBar.visibility = View.VISIBLE
            currentId = TEST_ID
            open(TEST_ID, "https://accounts.google.com/")
            return
        }
        b.accountBar.visibility = View.VISIBLE
        b.testBar.visibility = View.GONE
        val id = i?.getStringExtra(EXTRA_ID)
            ?: currentId.takeIf { it.isNotEmpty() && it != TEST_ID }
            ?: AccountStore.all().firstOrNull()?.id
        if (id == null) {
            goToList()
            return
        }
        show(id)
    }

    private fun show(id: String) {
        if (AccountStore.get(id) == null) return
        currentId = id
        open(id, Browser.URL_WPLACE)
        refreshBar()
    }

    private fun switchTo(id: String) {
        if (id == currentId) return
        Browser.closePopup(currentId)
        show(id)
    }

    /** Suelta la sesión actual de la vista (sigue viva en memoria) y muestra la de `id`. */
    private fun open(id: String, url: String) {
        try {
            hidePopup()
            val prev: GeckoSession? = runCatching { b.gecko.releaseSession() }.getOrNull()
            val s = Browser.sessionFor(this, id, url)
            if (prev != null && prev !== s) runCatching { prev.setActive(false) }
            b.gecko.setSession(s)
            s.setActive(true)
        } catch (e: Throwable) {
            Log.e(TAG, "open", e)
            Crumbs.add("ERR open ${e.javaClass.simpleName}")
            Toast.makeText(this, "No se pudo mostrar la página. Toca ⟳ para reintentar.", Toast.LENGTH_LONG).show()
        }
    }

    private fun goToList() {
        if (!testMode) {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
        finish()
    }

    private fun goNext() {
        val c = AccountStore.config()
        val now = System.currentTimeMillis()
        val next = Timers.sorted(AccountStore.all(), c, now)
            .firstOrNull { it.id != currentId && Timers.bucket(it, c, now) <= 1 }
        if (next == null) {
            Toast.makeText(this, "Ninguna otra cuenta tiene píxeles ahora mismo", Toast.LENGTH_SHORT).show()
        } else {
            switchTo(next.id)
        }
    }

    private fun markEmpty() {
        val a = AccountStore.update(currentId) { it.copy(emptyAt = System.currentTimeMillis()) } ?: return
        Alarms.schedule(this, a)
        val rem = Timers.remaining(a, AccountStore.config(), System.currentTimeMillis())
        Toast.makeText(this, "${a.name}: te aviso en ${Timers.fmt(rem)}", Toast.LENGTH_LONG).show()
        refreshBar()
    }

    // ---------- Ventana emergente (login en popup) ----------
    private fun showPopup(p: GeckoSession, tries: Int) {
        if (isFinishing || isDestroyed) return
        try {
            b.popupLayer.visibility = View.VISIBLE
            b.popupGecko.releaseSession()
            b.popupGecko.setSession(p)
            p.setActive(true)
        } catch (e: Throwable) {
            // la sesión aún no está abierta: reintentar un momento después
            if (tries < 20) {
                handler.postDelayed({ showPopup(p, tries + 1) }, 50)
            } else {
                Crumbs.add("ERR popup no se pudo mostrar")
                b.popupLayer.visibility = View.GONE
            }
        }
    }

    private fun hidePopup() {
        runCatching { b.popupGecko.releaseSession() }
        b.popupLayer.visibility = View.GONE
    }

    private fun showBlocked() {
        if (blockedShown || isFinishing || isDestroyed) return
        blockedShown = true
        MaterialAlertDialogBuilder(this)
            .setTitle("Google bloqueó el inicio de sesión")
            .setMessage("Se detectó el error 403 / disallowed_useragent. Prueba con una versión más reciente de GeckoView (gradle.properties) y vuelve a compilar.")
            .setPositiveButton("Entendido", null)
            .show()
    }

    // ---------- Barra inferior ----------
    private fun refreshBar() {
        if (testMode) return
        val accs = AccountStore.all()
        val c = AccountStore.config()
        val now = System.currentTimeMillis()
        syncChips(accs, c, now)

        val acc = accs.firstOrNull { it.id == currentId } ?: return
        val parts = mutableListOf(Timers.timerLine(acc, c, now))
        val ses = Timers.sessionLine(acc)
        if (ses != null && acc.sessionState != SessionState.OK) parts.add(ses)
        b.statusText.text = acc.name + " · " + parts.joinToString(" · ")
        b.statusText.setTextColor(
            color(if (acc.sessionState == SessionState.EXPIRED) R.color.warn else R.color.muted)
        )
    }

    private fun syncChips(accs: List<Account>, c: Config, now: Long) {
        if (accs.map { it.id } != chips.keys.toList()) {
            b.chipRow.removeAllViews()
            chips.clear()
            for (a in accs) {
                val btn = MaterialButton(this).apply {
                    insetTop = 0
                    insetBottom = 0
                    minimumWidth = 0
                    cornerRadius = dp(22)
                    setPadding(dp(16), 0, dp(16), 0)
                    setOnClickListener { switchTo(a.id) }
                }
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
                lp.marginEnd = dp(8)
                b.chipRow.addView(btn, lp)
                chips[a.id] = btn
            }
        }
        for (a in accs) {
            val btn = chips[a.id] ?: continue
            val ready = Timers.hasTimer(a) && Timers.remaining(a, c, now) == 0L
            val sel = a.id == currentId
            btn.text = (if (ready) "● " else "") + a.name
            btn.backgroundTintList = ColorStateList.valueOf(color(if (sel) R.color.accent else R.color.chip))
            btn.setTextColor(
                color(
                    when {
                        sel -> R.color.on_accent
                        ready -> R.color.accent
                        else -> R.color.text
                    }
                )
            )
        }
    }
}
