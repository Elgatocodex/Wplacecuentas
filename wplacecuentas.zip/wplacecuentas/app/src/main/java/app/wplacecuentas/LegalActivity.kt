package app.wplacecuentas

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import app.wplacecuentas.databinding.ActivityLegalBinding

class LegalActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_DOC = "doc"
        const val EXTRA_TITLE = "title"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityLegalBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.toolbar.title = intent.getStringExtra(EXTRA_TITLE) ?: "Legal"
        b.toolbar.setNavigationOnClickListener { finish() }
        val name = intent.getStringExtra(EXTRA_DOC) ?: "terminos"
        val text = try {
            LegalText.load(this, name)
        } catch (e: Exception) {
            "No se pudo cargar el documento. Está disponible en ${Links.REPO}"
        }
        b.doc.text = LegalText.render(this, text)
    }
}
