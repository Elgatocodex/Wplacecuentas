package app.wplacecuentas

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import app.wplacecuentas.databinding.ActivityAboutBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class AboutActivity : AppCompatActivity() {
    private lateinit var b: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.toolbar.setNavigationOnClickListener { finish() }

        val v = (application as App).versionName()
        b.version.text = "Versión $v · Licencia MIT"

        b.btnUpdate.setOnClickListener { Links.open(this, Links.DOWNLOADS) }
        b.btnSource.setOnClickListener { Links.open(this, Links.REPO) }
        b.btnIssues.setOnClickListener { Links.open(this, Links.ISSUES) }
        b.btnTerms.setOnClickListener { doc("terminos", "Términos y condiciones") }
        b.btnPrivacy.setOnClickListener { doc("privacidad", "Política de privacidad") }
        b.btnCookies.setOnClickListener { doc("cookies", "Política de cookies") }
        b.btnLicenses.setOnClickListener { doc("licencias", "Licencias y avisos") }
        b.btnWipe.setOnClickListener { confirmWipe() }
    }

    private fun doc(name: String, title: String) {
        startActivity(
            Intent(this, LegalActivity::class.java)
                .putExtra(LegalActivity.EXTRA_DOC, name)
                .putExtra(LegalActivity.EXTRA_TITLE, title)
        )
    }

    private fun confirmWipe() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Borrar todos los datos")
            .setMessage("Se eliminarán todas las cuentas, sus sesiones (cookies y datos de Google y wplace), los temporizadores y los avisos. No se puede deshacer.")
            .setPositiveButton("Borrar todo") { _, _ ->
                for (a in AccountStore.all()) {
                    Alarms.cancel(this, a.id)
                    Browser.delete(this, a.id)
                }
                AccountStore.clearAll()
                Crumbs.clear()
                Toast.makeText(this, "Datos borrados", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
