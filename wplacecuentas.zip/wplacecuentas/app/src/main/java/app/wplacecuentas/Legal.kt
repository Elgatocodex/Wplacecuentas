package app.wplacecuentas

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import android.widget.Toast
import androidx.core.content.ContextCompat

const val LEGAL_VERSION = 1

object Links {
    const val REPO = "https://github.com/Elgatocodex/Wplacecuentas"
    const val ISSUES = "$REPO/issues"
    const val DOWNLOADS = "https://apannet.netlify.app/"

    fun open(ctx: Context, url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(ctx, "No se encontró un navegador para abrir el enlace", Toast.LENGTH_LONG).show()
        }
    }
}

object LegalText {
    fun load(ctx: Context, name: String): String =
        ctx.assets.open("legal/$name.md").bufferedReader().use { it.readText() }

    /** Mini-formato: «# » título, «## » subtítulo, «- » viñeta. */
    fun render(ctx: Context, text: String): CharSequence {
        val accent = ContextCompat.getColor(ctx, R.color.accent)
        val sb = SpannableStringBuilder()
        for (line in text.lines()) {
            val start = sb.length
            when {
                line.startsWith("## ") -> {
                    sb.append(line.removePrefix("## "))
                    sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(1.12f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(ForegroundColorSpan(accent), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                line.startsWith("# ") -> {
                    sb.append(line.removePrefix("# "))
                    sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(1.45f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                line.startsWith("- ") -> sb.append("• ").append(line.removePrefix("- "))
                else -> sb.append(line)
            }
            sb.append('\n')
        }
        return sb
    }
}
