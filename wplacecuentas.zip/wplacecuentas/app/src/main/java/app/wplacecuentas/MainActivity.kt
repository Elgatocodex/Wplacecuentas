package app.wplacecuentas

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import app.wplacecuentas.databinding.ActivityMainBinding
import app.wplacecuentas.databinding.DialogSettingsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

class MainActivity : AppCompatActivity() {
    companion object {
        private var diagChecked = false   // se comprueba una vez por arranque del proceso
    }

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: AccountAdapter
    private var legalShowing = false
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }
    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        adapter = AccountAdapter(::openAccount, ::markEmpty, ::showMenu)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.list.itemAnimator = null

        b.fabAdd.setOnClickListener { addAccount() }
        b.toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_settings -> { showSettings(); true }
                R.id.action_test -> { startTest(); true }
                R.id.action_update -> { Links.open(this, Links.DOWNLOADS); true }
                R.id.action_about -> { startActivity(Intent(this, AboutActivity::class.java)); true }
                else -> false
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        Alarms.rescheduleAll(this)
        Browser.onSessionState = { refresh() }
        handler.post(ticker)
        ensureLegal()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        Browser.onSessionState = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Aceptación legal (primer arranque o cambio de versión) ----------
    private fun ensureLegal() {
        if (AccountStore.legalVersion() >= LEGAL_VERSION) {
            checkDiagnostics()
            return
        }
        if (legalShowing) return
        legalShowing = true
        MaterialAlertDialogBuilder(this)
            .setTitle("Antes de empezar")
            .setMessage(
                "WplaceCuentas es software libre (MIT) y no está afiliada a wplace.live ni a Google.\n\n" +
                    "• Todo se guarda solo en tu dispositivo: sin servidores ni analíticas.\n" +
                    "• Inicias sesión tú en la página de Google; la app no ve ni guarda contraseñas.\n" +
                    "• Eres responsable de cumplir las normas de wplace.live y de Google, incluidas las de uso de varias cuentas.\n\n" +
                    "Al pulsar «Acepto» confirmas que has leído y aceptas los Términos y condiciones, la Política de privacidad y la Política de cookies."
            )
            .setCancelable(false)
            .setPositiveButton("Acepto") { _, _ ->
                AccountStore.acceptLegal(LEGAL_VERSION)
                checkDiagnostics()
            }
            .setNeutralButton("Leer documentos") { _, _ ->
                startActivity(Intent(this, AboutActivity::class.java))
            }
            .setNegativeButton("Salir") { _, _ -> finishAffinity() }
            .setOnDismissListener { legalShowing = false }
            .show()
    }

    // ---------- Informe de cierres inesperados ----------
    private fun checkDiagnostics() {
        if (diagChecked) return
        diagChecked = true
        val f = File(filesDir, "crash.txt")
        when {
            f.exists() -> {
                val txt = try { f.readText() } catch (e: Exception) { "No se pudo leer el informe." }
                f.delete()
                Crumbs.setActive(false)
                showReport("La app se cerró la última vez", txt)
            }
            Crumbs.wasActive() -> {
                Crumbs.setActive(false)
                showReport(
                    "Cierre inesperado del navegador",
                    "El navegador integrado se detuvo de forma inesperada.\n\n--- Últimos eventos ---\n" + Crumbs.dump()
                )
            }
        }
    }

    private fun showReport(title: String, text: String) {
        val tv = TextView(this).apply {
            this.text = text
            setTextIsSelectable(true)
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(getColor(R.color.text))
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage("Puedes copiar este informe y enviarlo en Reportar un problema (Acerca de). No contiene contraseñas.")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copiar") { _, _ ->
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("informe", text))
                Toast.makeText(this, "Informe copiado", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Compartir") { _, _ ->
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Compartir informe"))
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    // ---------- Lista ----------
    private fun refresh() {
        val c = AccountStore.config()
        val now = System.currentTimeMillis()
        val sorted = Timers.sorted(AccountStore.all(), c, now)
        val rows = sorted.map { a ->
            val bucket = Timers.bucket(a, c, now)
            val px = Timers.pixels(a, c, now)
            Row(
                id = a.id,
                name = a.name,
                timer = Timers.timerLine(a, c, now),
                session = Timers.sessionLine(a),
                warn = a.sessionState == SessionState.EXPIRED,
                bucket = bucket,
                progress = if (px == null) 0 else (px * 100 / c.maxPixels),
                showProgress = px != null
            )
        }
        adapter.submitList(rows)
        b.emptyText.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE

        val ready = sorted.count { Timers.bucket(it, c, now) == 0 }
        val waiting = sorted.count { Timers.bucket(it, c, now) == 2 }
        val expired = sorted.count { it.sessionState == SessionState.EXPIRED }
        b.summary.text = if (sorted.isEmpty()) "Sin cuentas todavía" else buildString {
            append("$ready con píxeles · $waiting esperando")
            if (expired > 0) append(" · $expired con sesión caducada")
        }
    }

    // ---------- Acciones ----------
    private fun openAccount(id: String) {
        startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_ID, id))
    }

    private fun addAccount() {
        val names = AccountStore.all().map { it.name }.toSet()
        var n = AccountStore.all().size + 1
        while ("Cuenta $n" in names) n++
        val a = AccountStore.add("Cuenta $n")
        refresh()
        openAccount(a.id)
    }

    private fun markEmpty(id: String) {
        val a = AccountStore.update(id) { it.copy(emptyAt = System.currentTimeMillis()) } ?: return
        Alarms.schedule(this, a)
        val c = AccountStore.config()
        val rem = Timers.remaining(a, c, System.currentTimeMillis())
        Toast.makeText(this, "${a.name}: te aviso en ${Timers.fmt(rem)}", Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun showMenu(id: String, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menuInflater.inflate(R.menu.account_menu, pm.menu)
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.rename -> rename(id)
                R.id.clear_timer -> clearTimer(id)
                R.id.delete -> confirmDelete(id)
            }
            true
        }
        pm.show()
    }

    private fun rename(id: String) {
        val a = AccountStore.get(id) ?: return
        val input = EditText(this).apply {
            setText(a.name)
            setSelection(text.length)
            setSingleLine()
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Nombre de la cuenta")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) {
                    AccountStore.update(id) { it.copy(name = n) }
                    refresh()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun clearTimer(id: String) {
        val a = AccountStore.update(id) { it.copy(emptyAt = 0L) } ?: return
        Alarms.cancel(this, a.id)
        refresh()
    }

    private fun confirmDelete(id: String) {
        val a = AccountStore.get(id) ?: return
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar «${a.name}»")
            .setMessage("Se borrará la sesión de esta cuenta (cookies y datos de wplace y de Google) en este dispositivo. No se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                Alarms.cancel(this, id)
                Browser.delete(this, id)
                AccountStore.remove(id)
                refresh()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startTest() {
        startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_TEST, true))
    }

    private fun showSettings() {
        val c = AccountStore.config()
        val d = DialogSettingsBinding.inflate(layoutInflater)
        d.inMpp.setText(c.minutesPerPixel.toString())
        d.inMax.setText(c.maxPixels.toString())
        d.inNotify.setText(c.notifyAt.toString())
        d.inPages.setText(c.pagesInMemory.toString())
        MaterialAlertDialogBuilder(this)
            .setTitle("Temporizador y ajustes")
            .setView(d.root)
            .setPositiveButton("Guardar") { _, _ ->
                val mpp = d.inMpp.text.toString().replace(',', '.').toDoubleOrNull()
                val max = d.inMax.text.toString().toIntOrNull()
                val notify = d.inNotify.text.toString().toIntOrNull()
                val pages = d.inPages.text.toString().toIntOrNull()
                if (mpp == null || mpp <= 0.0 || max == null || max < 1 ||
                    notify == null || notify < 1 || pages == null || pages < 1
                ) {
                    Toast.makeText(this, "Valores no válidos, no se guardó nada", Toast.LENGTH_LONG).show()
                } else {
                    AccountStore.saveConfig(Config(mpp, max, notify.coerceAtMost(max), pages))
                    Alarms.rescheduleAll(this)
                    refresh()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
