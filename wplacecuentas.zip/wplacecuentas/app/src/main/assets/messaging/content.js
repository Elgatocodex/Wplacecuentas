// Solo LEE el estado de sesión (GET /me). No toca la página ni juega por ti.
(function () {
  "use strict";
  var busy = false;

  function send(state) {
    try {
      var p = browser.runtime.sendNativeMessage("browser", { type: "auth", state: state });
      if (p && p.catch) { p.catch(function () {}); }
    } catch (e) {}
  }

  async function check() {
    if (busy) { return; }
    busy = true;
    var state = "unknown";
    try {
      var r = await fetch("https://backend.wplace.live/me", { credentials: "include" });
      if (r.status === 401) {
        state = "out";
      } else if (r.ok) {
        try {
          var j = await r.json();
          state = (j && j.id !== undefined && j.id !== null) ? "ok" : "out";
        } catch (e) { state = "unknown"; }
      }
    } catch (e) { state = "unknown"; }
    busy = false;
    send(state);
  }

  check();
  setInterval(check, 45000);
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) { check(); }
  });
})();
