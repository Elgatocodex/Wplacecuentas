# Términos y condiciones de uso
Última actualización: 28 de octubre de 2026

## 1. Qué es esta aplicación
WplaceCuentas («la App») es una aplicación gratuita y de código abierto (licencia MIT) publicada por Elgatocodex («el autor»). Sirve para mantener varias sesiones separadas del sitio web wplace.live en un mismo dispositivo y para llevar temporizadores de recarga de píxeles.
- Código fuente: https://github.com/Elgatocodex/Wplacecuentas
- Descargas y actualizaciones: https://apannet.netlify.app/

## 2. Independencia y marcas
La App es un proyecto independiente. No está afiliada, respaldada ni patrocinada por wplace.live, Google, Gmail, Mozilla ni Firefox. Todos los nombres y marcas pertenecen a sus respectivos propietarios y se mencionan solo para identificar los servicios con los que la App es compatible.

## 3. Aceptación
Al instalar o usar la App aceptas estos términos, la Política de privacidad y la Política de cookies. Si no estás de acuerdo, no uses la App y desinstálala.

## 4. Uso permitido
- Debes tener la edad mínima exigida por Google y por wplace.live en tu país para usar sus servicios.
- Eres el único responsable de las cuentas que añades y de cumplir los términos y normas de wplace.live y de Google. Esos servicios pueden limitar o prohibir el uso de varias cuentas; si lo hacen, las sanciones (por ejemplo, suspensión o bloqueo de cuentas) son responsabilidad tuya.
- No debes usar la App para automatizar acciones en el juego, hacer trampas, eludir límites o abusar de ningún servicio.

## 5. Qué NO hace la App
- No coloca píxeles ni realiza clics o acciones por ti.
- No pide, lee ni guarda tus contraseñas: inicias sesión tú mismo en la página de Google.
- No envía datos al autor ni a ningún servidor propio.

## 6. Servicios de terceros
La App muestra sitios web de terceros (Google, wplace.live) en un navegador integrado. No los controlamos y no somos responsables de su contenido, disponibilidad ni de sus políticas, que se aplican cuando los usas.

## 7. Sin garantías
La App se ofrece «tal cual» y «según disponibilidad». Los temporizadores y los píxeles mostrados son estimaciones basadas en los valores que configuras. No garantizamos que sean exactos, que la App funcione sin errores, ni que las notificaciones lleguen puntualmente: Android puede retrasarlas por el ahorro de batería.

## 8. Limitación de responsabilidad
En la medida máxima permitida por la ley, el autor no será responsable de daños indirectos ni de la pérdida de cuentas, datos, progreso o acceso a servicios derivados del uso de la App. Nada de lo aquí dispuesto excluye la responsabilidad que no pueda excluirse legalmente, incluidos los derechos irrenunciables de los consumidores.

## 9. Código abierto
El código de la App se distribuye bajo la licencia MIT (ver «Licencias y avisos»). Puedes usarlo, copiarlo y modificarlo según esa licencia. Los componentes de terceros mantienen sus propias licencias.

## 10. Actualizaciones y descargas
La App no se actualiza sola ni consulta si hay versiones nuevas. Para actualizar, usa el botón «Buscar actualizaciones», que abre el sitio de descargas en tu navegador. Instala archivos APK solo desde las fuentes oficiales indicadas arriba; el autor no se responsabiliza de copias descargadas de otros sitios.

## 11. Cambios en estos términos
Podemos actualizar estos términos. La fecha de última actualización aparece arriba y, si el cambio es sustancial, la App te pedirá aceptarlos de nuevo.

## 12. Ley aplicable y contacto
Estos términos se rigen por la ley del lugar de residencia del autor, sin perjuicio de las normas imperativas de protección al consumidor de tu país. Para dudas, problemas o solicitudes: https://github.com/Elgatocodex/Wplacecuentas/issues
