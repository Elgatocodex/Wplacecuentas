# Licencias y avisos de terceros

## WplaceCuentas
Copyright (c) 2026 Elgatocodex. Distribuida bajo la licencia MIT.
Código fuente: https://github.com/Elgatocodex/Wplacecuentas

    MIT License

    Copyright (c) 2026 Elgatocodex

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.

## Componentes de terceros
- GeckoView (Mozilla): licencia Mozilla Public License 2.0, https://www.mozilla.org/MPL/2.0/. Se usa sin modificar, como biblioteca binaria publicada por Mozilla. Su código fuente está disponible en https://firefox-source-docs.mozilla.org
- AndroidX (appcompat, core-ktx, recyclerview): licencia Apache 2.0, https://www.apache.org/licenses/LICENSE-2.0
- Material Components for Android: licencia Apache 2.0.
- Kotlin y su biblioteca estándar: licencia Apache 2.0.

## Marcas
Firefox y Mozilla son marcas de Mozilla. Google y Gmail son marcas de Google LLC. wplace.live pertenece a sus propietarios. Este proyecto no está afiliado a ninguno de ellos.
