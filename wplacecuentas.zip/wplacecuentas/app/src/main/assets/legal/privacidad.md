# Política de privacidad
Última actualización: 28 de octubre de 2026

Resumen: la App no recopila datos personales ni los envía al autor. Todo lo que guarda se queda en tu dispositivo.

## 1. Responsable
Elgatocodex, autor de WplaceCuentas. Contacto: https://github.com/Elgatocodex/Wplacecuentas/issues

## 2. Qué guarda la App en tu dispositivo
- Los nombres de cuenta que escribes, la hora en que marcas «Se acabaron los píxeles», el estado de la sesión (activa o caducada) y tus ajustes del temporizador.
- Una sesión de navegación separada por cada cuenta (cookies y almacenamiento local) que crean Google y wplace.live dentro del navegador integrado.
- El estado de navegación de cada cuenta (páginas del historial y posición en la página), para restaurarla si Android cierra la app por falta de memoria o si sales a otra app a leer un código. Puede incluir direcciones de páginas visitadas; se guarda solo en el dispositivo y se borra al eliminar la cuenta o al usar «Borrar todos los datos».
- Un registro técnico local de fallos y de los últimos eventos (por ejemplo, el nombre del sitio visitado, sin la dirección completa). Solo se comparte si tú decides copiarlo y enviarlo.

## 3. Qué NO recopila
- Contraseñas: las escribes en la página de Google y la App no las lee ni las guarda.
- No hay analíticas, publicidad, rastreadores, cuentas de usuario ni servidores del autor.

## 4. Comunicaciones de red
La App no se conecta a servidores del autor. El navegador integrado se conecta directamente a Google y a wplace.live, que reciben tu dirección IP y tus datos de navegación según sus propias políticas. Además, una pequeña extensión interna consulta de forma periódica https://backend.wplace.live/me con tu sesión, solo mientras hay una página de wplace.live abierta, para saber si la sesión sigue activa. El resultado se usa únicamente de forma local.

## 5. Permisos
- Internet y estado de la red: necesarios para el navegador integrado.
- Notificaciones: para avisarte cuando una cuenta tenga píxeles.
- Inicio del dispositivo: para reprogramar los avisos tras reiniciar el teléfono.

## 6. Tus derechos
Como el autor no recibe tus datos personales, no los trata. Los datos están en tu dispositivo y los controlas tú: puedes eliminar una cuenta, usar «Borrar todos los datos» en la sección «Acerca de», borrar los datos desde los ajustes de Android o desinstalar la App. Para ejercer derechos sobre los datos que tratan Google o wplace.live (acceso, rectificación, supresión, etc.), dirígete a ellos.

## 7. Menores
La App no está dirigida a menores de la edad mínima exigida por Google y wplace.live en su país. Si eres menor, usa la App solo con permiso y supervisión de tu madre, padre o tutor.

## 8. Seguridad
Los datos se guardan en el almacenamiento privado de la App y la copia de seguridad automática de Android está desactivada. Protege tu teléfono con bloqueo de pantalla y descarga la App solo desde las fuentes oficiales.

## 9. Cambios
Podemos actualizar esta política. La fecha de última actualización aparece arriba.
