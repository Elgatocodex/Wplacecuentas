# Política de cookies y almacenamiento local
Última actualización: 28 de octubre de 2026

## 1. Qué son
Las cookies y el almacenamiento local son pequeños datos que los sitios web guardan en tu dispositivo para recordar tu sesión y tus preferencias.

## 2. La App no usa cookies propias
WplaceCuentas no crea cookies ni utiliza rastreadores. Por eso no muestra un banner de consentimiento de cookies propio.

## 3. Cookies de los sitios que visitas
El navegador integrado carga Google (para iniciar sesión) y wplace.live. Esos sitios guardan cookies y almacenamiento local necesarios para mantener tu sesión, la seguridad y tus preferencias. La App mantiene esos datos en un perfil separado por cada cuenta, almacenado solo en tu dispositivo. Su uso se rige por las políticas de cookies de Google y de wplace.live, que pueden mostrar sus propios avisos.

## 4. Cómo gestionarlas
- Eliminar cuenta: borra las cookies y los datos de esa cuenta.
- Acerca de, «Borrar todos los datos de la app»: borra todas las cuentas y sus sesiones.
- Ajustes de Android, Aplicaciones, WplaceCuentas, Almacenamiento: «Borrar datos».
- Desinstalar la App elimina todo.

## 5. Bloqueo de cookies
La App no permite bloquear cookies porque son imprescindibles para iniciar sesión en Google y en wplace.live.

## 6. Cambios
Podemos actualizar esta política. La fecha aparece arriba.
